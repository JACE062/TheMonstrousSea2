import '../model/bloodline_trait.dart';
import '../model/combatant.dart';
import '../model/covenant_of_the_deep.dart';
import '../model/item.dart';
import '../model/material_shipment.dart';
import '../model/wreck_encounter.dart';
import '../session/game_session.dart';
import '../session/session_phase.dart';
import '../rules/paid_repairs.dart';

/// Captures transient mid-voyage session state so that players can pause
/// and resume a run across application launches.
///
/// Ordinary death/home preparation clears the checkpoint. Resolved Caldera
/// outcomes remain readable across restart, including the offered heirs.
class VoyageSaveData {
  VoyageSaveData({
    required this.captainName,
    required this.ship,
    required this.regionIndex,
    required this.currentRow,
    required this.currentCol,
    required this.timesCompleted,
    this.activeBoonId,
    this.activeQuirkId,
    required this.phase,
    this.battleRound = 1,
    this.lastGoldSalvaged = 0,
    this.monstersDefeatedThisLife = 0,
    this.highestDifficultyThisLife = 1,
    List<Item>? pendingLoot,
    List<Item>? merchantStock,
    this.onSaleMerchantIndex,
    this.gunneryAccuracyBoon = 0,
    this.runicGuidanceBoon = 0,
    this.stormSeerRedrawRegion,
    this.shrineOmenSeed = 0,
    this.hasClaimedSmugglerGift = false,
    this.seaChartState,
    this.hasDefeatedCurrentEncounter = false,
    this.merchantReturnPhase,
    this.hasSalvagedCurrentWreck = false,
    this.currentShipwreckName = '',
    this.wreckSalvageReceipt = const [],
    this.calderaOutcome,
    this.hasReadCalderaOutcome = false,
    this.pendingHeirCandidates = const [],
    this.currentIslandName = '',
    this.hasCareenedAtCurrentIsland = false,
    this.hasDrilledAtCurrentIsland = false,
    this.hasForagedAtCurrentIsland = false,
    this.currentWreck,
    this.merchantMaterials,
    this.smugglerMaterials,
    this.shoreDrillBoon = 0,
    PaidRepairWork? paidRepairWork,
  }) : pendingLoot = pendingLoot ?? <Item>[],
       merchantStock = merchantStock ?? <Item>[],
       paidRepairWork = paidRepairWork ?? PaidRepairWork();

  factory VoyageSaveData.fromJson(Map<String, dynamic> json) {
    final shipJson = json['ship'] as Map<String, dynamic>;
    final phaseName = json['phase'] as String;
    final phase = SessionPhase.values.firstWhere(
      (e) => e.name == phaseName,
      orElse: () => SessionPhase.port,
    );

    final boonName = json['activeBoonId'] as String?;
    final boonId = boonName != null
        ? BloodlineTraitId.values.firstWhere((e) => e.name == boonName)
        : null;

    final quirkName = json['activeQuirkId'] as String?;
    final quirkId = quirkName != null
        ? BloodlineTraitId.values.firstWhere((e) => e.name == quirkName)
        : null;

    final lootList = (json['pendingLoot'] as List<dynamic>?)
        ?.map((e) => Item.fromJson(e as Map<String, dynamic>))
        .toList();

    final stockList = (json['merchantStock'] as List<dynamic>?)
        ?.map((e) => Item.fromJson(e as Map<String, dynamic>))
        .toList();

    return VoyageSaveData(
      shoreDrillBoon: json['shoreDrillBoon'] as int? ?? 0,
      paidRepairWork: json['paidRepairWork'] == null ? null : PaidRepairWork.fromJson(Map<String, dynamic>.from(json['paidRepairWork'] as Map)),
      merchantMaterials: json['merchantMaterials'] == null ? null : MaterialShipment.fromJson(Map<String, dynamic>.from(json['merchantMaterials'] as Map)),
      smugglerMaterials: json['smugglerMaterials'] == null ? null : MaterialShipment.fromJson(Map<String, dynamic>.from(json['smugglerMaterials'] as Map)),
      currentWreck: json['currentWreck'] == null ? null : WreckEncounter.fromJson(Map<String, dynamic>.from(json['currentWreck'] as Map)),
      currentIslandName: json['currentIslandName'] as String? ?? '',
      hasCareenedAtCurrentIsland: json['hasCareenedAtCurrentIsland'] as bool? ?? false,
      hasDrilledAtCurrentIsland: json['hasDrilledAtCurrentIsland'] as bool? ?? false,
      hasForagedAtCurrentIsland: json['hasForagedAtCurrentIsland'] as bool? ?? false,
      captainName: json['captainName'] as String? ?? 'Captain',
      ship: ShipState.fromJson(shipJson),
      regionIndex: json['regionIndex'] as int? ?? 0,
      currentRow: json['currentRow'] as int? ?? 0,
      currentCol: json['currentCol'] as int? ?? 0,
      timesCompleted: json['timesCompleted'] as int? ?? 0,
      activeBoonId: boonId,
      activeQuirkId: quirkId,
      phase: phase,
      calderaOutcome: CalderaClimaxChoice.values
          .where((choice) => choice.name == json['calderaOutcome'])
          .firstOrNull,
      hasReadCalderaOutcome: json['hasReadCalderaOutcome'] as bool? ?? false,
      pendingHeirCandidates: (json['pendingHeirCandidates'] as List?)
          ?.map((candidate) => HeirCandidate.fromJson(
            candidate as Map<String, dynamic>))
          .toList() ?? const [],
      hasSalvagedCurrentWreck: json['hasSalvagedCurrentWreck'] as bool? ?? false,
      currentShipwreckName: json['currentShipwreckName'] as String? ?? '',
      wreckSalvageReceipt: (json['wreckSalvageReceipt'] as List?)?.cast<String>() ?? const [],
      merchantReturnPhase: json['merchantReturnPhase'] == 'stronghold'
          ? SessionPhase.stronghold
          : json['merchantReturnPhase'] == 'helm'
          ? SessionPhase.helm
          : json['merchantReturnPhase'] == 'port'
          ? SessionPhase.port
          : null,
      battleRound: json['battleRound'] as int? ?? 1,
      lastGoldSalvaged: json['lastGoldSalvaged'] as int? ?? 0,
      monstersDefeatedThisLife: json['monstersDefeatedThisLife'] as int? ?? 0,
      highestDifficultyThisLife: json['highestDifficultyThisLife'] as int? ?? 1,
      pendingLoot: lootList,
      merchantStock: stockList,
      onSaleMerchantIndex: json['onSaleMerchantIndex'] as int?,
      gunneryAccuracyBoon: json['gunneryAccuracyBoon'] as int? ?? 0,
      runicGuidanceBoon: json['runicGuidanceBoon'] as int? ?? 0,
      stormSeerRedrawRegion: json['stormSeerRedrawRegion'] as int?,
      shrineOmenSeed: json['shrineOmenSeed'] as int? ?? 0,
      hasClaimedSmugglerGift: json['hasClaimedSmugglerGift'] as bool? ?? false,
      seaChartState: json['seaChartState'] as Map<String, dynamic>?,
      hasDefeatedCurrentEncounter:
          json['hasDefeatedCurrentEncounter'] as bool? ??
          phase == SessionPhase.restArea,
    );
  }

  final String captainName;
  final ShipState ship;
  final int regionIndex;
  final int currentRow;
  final int currentCol;
  final int timesCompleted;
  final BloodlineTraitId? activeBoonId;
  final BloodlineTraitId? activeQuirkId;
  final SessionPhase phase;
  final CalderaClimaxChoice? calderaOutcome;
  final bool hasReadCalderaOutcome;
  final List<HeirCandidate> pendingHeirCandidates;
  final bool hasSalvagedCurrentWreck;
  final String currentShipwreckName;
  final List<String> wreckSalvageReceipt;
  final SessionPhase? merchantReturnPhase;
  final int battleRound;
  final int lastGoldSalvaged;
  final int monstersDefeatedThisLife;
  final int highestDifficultyThisLife;
  final List<Item> pendingLoot;
  final List<Item> merchantStock;
  final int? onSaleMerchantIndex;
  final int gunneryAccuracyBoon;
  final int runicGuidanceBoon;
  final int? stormSeerRedrawRegion;
  final int shrineOmenSeed;
  final bool hasClaimedSmugglerGift;
  final Map<String, dynamic>? seaChartState;
  final bool hasDefeatedCurrentEncounter;
  final String currentIslandName;
  final bool hasCareenedAtCurrentIsland;
  final bool hasDrilledAtCurrentIsland;
  final bool hasForagedAtCurrentIsland;
  final WreckEncounter? currentWreck;
  final MaterialShipment? merchantMaterials, smugglerMaterials;
  final int shoreDrillBoon;
  final PaidRepairWork paidRepairWork;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'shoreDrillBoon': shoreDrillBoon,
    'paidRepairWork': paidRepairWork.toJson(),
    'merchantMaterials': merchantMaterials?.toJson(),
    'smugglerMaterials': smugglerMaterials?.toJson(),
    'currentWreck': currentWreck?.toJson(),
    'currentIslandName': currentIslandName,
    'hasCareenedAtCurrentIsland': hasCareenedAtCurrentIsland,
    'hasDrilledAtCurrentIsland': hasDrilledAtCurrentIsland,
    'hasForagedAtCurrentIsland': hasForagedAtCurrentIsland,
    'captainName': captainName,
    'ship': ship.toJson(),
    'regionIndex': regionIndex,
    'currentRow': currentRow,
    'currentCol': currentCol,
    'timesCompleted': timesCompleted,
    'activeBoonId': activeBoonId?.name,
    'activeQuirkId': activeQuirkId?.name,
    'phase': phase.name,
    'calderaOutcome': calderaOutcome?.name,
    'hasReadCalderaOutcome': hasReadCalderaOutcome,
    'pendingHeirCandidates': pendingHeirCandidates
        .map((heir) => heir.toJson()).toList(),
    'hasSalvagedCurrentWreck': hasSalvagedCurrentWreck,
    'currentShipwreckName': currentShipwreckName,
    'wreckSalvageReceipt': wreckSalvageReceipt,
    'merchantReturnPhase': merchantReturnPhase?.name,
    'battleRound': battleRound,
    'lastGoldSalvaged': lastGoldSalvaged,
    'monstersDefeatedThisLife': monstersDefeatedThisLife,
    'highestDifficultyThisLife': highestDifficultyThisLife,
    'pendingLoot': pendingLoot.map((e) => e.toJson()).toList(),
    'merchantStock': merchantStock.map((e) => e.toJson()).toList(),
    'onSaleMerchantIndex': onSaleMerchantIndex,
    'gunneryAccuracyBoon': gunneryAccuracyBoon,
    'runicGuidanceBoon': runicGuidanceBoon,
    'stormSeerRedrawRegion': stormSeerRedrawRegion,
    'shrineOmenSeed': shrineOmenSeed,
    'hasClaimedSmugglerGift': hasClaimedSmugglerGift,
    'seaChartState': seaChartState,
    'hasDefeatedCurrentEncounter': hasDefeatedCurrentEncounter,
  };

  /// Constructs a [VoyageSaveData] snapshot from an active [GameSession].
  factory VoyageSaveData.fromSession(GameSession session) {
    if (session.ship == null) {
      throw StateError('Cannot create voyage save without an active ship');
    }
    return VoyageSaveData(
      shoreDrillBoon: session.shoreDrillBoon,
      paidRepairWork: PaidRepairWork.fromJson(session.paidRepairWork.toJson()),
      merchantMaterials: session.merchantMaterials == null ? null : MaterialShipment.fromJson(session.merchantMaterials!.toJson()),
      smugglerMaterials: session.smugglerMaterials == null ? null : MaterialShipment.fromJson(session.smugglerMaterials!.toJson()),
      currentWreck: session.currentWreck == null ? null : WreckEncounter.fromJson(session.currentWreck!.toJson()),
      currentIslandName: session.currentIslandName,
      hasCareenedAtCurrentIsland: session.hasCareenedAtCurrentIsland,
      hasDrilledAtCurrentIsland: session.hasDrilledAtCurrentIsland,
      hasForagedAtCurrentIsland: session.hasForagedAtCurrentIsland,
      captainName: session.captainName,
      ship: session.ship!,
      regionIndex: session.seaChart.currentRegionIndex,
      currentRow: session.seaChart.currentRow,
      currentCol: session.seaChart.currentCol,
      timesCompleted: session.seaChart.timesCompleted,
      activeBoonId: session.activeBoon?.id,
      activeQuirkId: session.activeQuirk?.id,
      phase: session.phase,
      calderaOutcome: session.calderaOutcome,
      hasReadCalderaOutcome: session.hasReadCalderaOutcome,
      pendingHeirCandidates: List<HeirCandidate>.from(
        session.pendingHeirCandidates),
      hasSalvagedCurrentWreck: session.hasSalvagedCurrentWreck,
      currentShipwreckName: session.currentShipwreckName,
      wreckSalvageReceipt: List<String>.from(session.wreckSalvageReceipt),
      merchantReturnPhase: session.merchantReturnPhase,
      battleRound: session.battleRound,
      lastGoldSalvaged: session.lastGoldSalvaged,
      monstersDefeatedThisLife: session.monstersDefeatedThisLife,
      highestDifficultyThisLife: session.highestDifficultyThisLife,
      pendingLoot: List<Item>.from(session.pendingLoot),
      merchantStock: List<Item>.from(session.merchantStock),
      onSaleMerchantIndex: session.onSaleMerchantIndex,
      gunneryAccuracyBoon: session.gunneryAccuracyBoon,
      runicGuidanceBoon: session.runicGuidanceBoon,
      stormSeerRedrawRegion: session.stormSeerRedrawRegion,
      shrineOmenSeed: session.shrineOmenSeed,
      hasClaimedSmugglerGift: session.hasClaimedSmugglerGift,
      seaChartState: session.seaChart.toJson(),
      hasDefeatedCurrentEncounter:
          session.hasDefeatedCurrentEncounter ||
          session.currentMonster?.isAlive == false,
    );
  }

  /// Restores session state from this saved voyage.
  void restoreToSession(GameSession session) {
    session.captainName = captainName;
    session.calderaOutcome = calderaOutcome;
    session.hasReadCalderaOutcome = hasReadCalderaOutcome;
    session.pendingHeirCandidates = _restorableHeirs(
      hasNemesis: session.profile.activeNemesis != null,
    );
    // Saved capacity already contains Quartermaster's voyage slot. Mark its
    // provenance before captain synchronization so reload cannot add it again.
    session.ship = null;
    final restoredBoon = activeBoonId == null ? null : BloodlineTrait.fromId(activeBoonId!);
    final restoredQuirk = activeQuirkId == null ? null : BloodlineTrait.fromId(activeQuirkId!);
    session.activeBoon = restoredBoon?.isBoon == true ? restoredBoon : null;
    session.activeQuirk = restoredQuirk?.isQuirk == true ? restoredQuirk : null;
    ship.captainCargoBonusApplied = activeBoonId == BloodlineTraitId.quartermaster;
    // Supported checkpoints are between battles. Serialized ships omit combat
    // statuses; also sanitize older in-memory snapshots without healing or
    // changing the saved build.
    if (phase != SessionPhase.battle) ship.statusEffects.clear();
    session.ship = ship;
    session.seaChart.timesCompleted = timesCompleted;
    session.seaChart.currentRow = currentRow;
    session.seaChart.currentCol = currentCol;
    if (seaChartState != null) {
      session.seaChart.restoreFromJson(seaChartState!);
      // Older checkpoints eagerly cached context-free future offers during an
      // encounter. Keep already offered helm choices stable, but generate unseen
      // choices with the restored profile's Nemesis and pacts on the next helm.
      if (phase != SessionPhase.helm) {
        session.seaChart.clearPendingCourses();
      }
    } else {
      // Older saves only recorded grid coordinates. Preserve their best-known
      // progress; subsequent steps use the authoritative voyage leg counter.
      session.seaChart.currentLeg =
          phase == SessionPhase.port || phase == SessionPhase.stronghold || phase == SessionPhase.merchant
          ? 0
          : (currentRow * 5 + currentCol + 1).clamp(
              1,
              session.seaChart.totalLegs,
            );
    }
    session.profile.hasBegunFirstVoyage = true;
    session.hasDefeatedCurrentEncounter = hasDefeatedCurrentEncounter;
    // Old checkpoints reused the home-port phase after defeating a Titan.
    // Reclassify these visits before any command can perform a new-run reset.
    session.phase =
        phase == SessionPhase.port && session.seaChart.currentRegionIndex > 0
        ? SessionPhase.stronghold
        : phase;
    session.merchantReturnPhase =
        merchantReturnPhase ??
        (session.seaChart.currentRegionIndex > 0
            ? SessionPhase.stronghold
            : SessionPhase.port);
    session.battleRound = battleRound;
    session.lastGoldSalvaged = lastGoldSalvaged;
    session.monstersDefeatedThisLife = monstersDefeatedThisLife;
    session.highestDifficultyThisLife = highestDifficultyThisLife;
    session.pendingLoot = List<Item>.from(pendingLoot);
    session.hasSalvagedCurrentWreck = hasSalvagedCurrentWreck;
    session.currentShipwreckName = currentShipwreckName;
    session.wreckSalvageReceipt = List<String>.from(wreckSalvageReceipt);
    session.merchantStock = List<Item>.from(merchantStock);
    session.onSaleMerchantIndex = onSaleMerchantIndex;
    session.gunneryAccuracyBoon = gunneryAccuracyBoon;
    session.runicGuidanceBoon = runicGuidanceBoon;
    session.stormSeerRedrawRegion = stormSeerRedrawRegion;
    session.shrineOmenSeed = shrineOmenSeed;
    session.hasClaimedSmugglerGift = hasClaimedSmugglerGift;
    session.currentIslandName = currentIslandName;
    session.shoreDrillBoon = shoreDrillBoon;
    session.paidRepairWork = PaidRepairWork.fromJson(paidRepairWork.toJson());
    session.merchantMaterials = merchantMaterials == null ? null : MaterialShipment.fromJson(merchantMaterials!.toJson());
    session.smugglerMaterials = smugglerMaterials == null ? null : MaterialShipment.fromJson(smugglerMaterials!.toJson());
    session.currentWreck = currentWreck == null ? null : WreckEncounter.fromJson(currentWreck!.toJson());
    session.hasCareenedAtCurrentIsland = hasCareenedAtCurrentIsland;
    session.hasDrilledAtCurrentIsland = hasDrilledAtCurrentIsland;
    session.hasForagedAtCurrentIsland = hasForagedAtCurrentIsland;
    session.syncCaptainTraits();
    if (session.phase == SessionPhase.shrine) {
      session.restoreShrineManifestations();
    }
    // A discarded legacy Titan offer must not leave a restored helm with no
    // buttons. Generate only missing offers, after restoring all voyage context.
    if (session.phase == SessionPhase.helm &&
        session.seaChart.currentCourseOptions.isEmpty) {
      session.seaChart.ensureCourseOptions(
        session.rng,
        session.profile.activeNemesis,
        session.profile.isPactActive(CovenantPactId.chokingFog),
        session.profile.isPactActive(CovenantPactId.apexEmergence),
        session.activeQuirk?.id == BloodlineTraitId.superstitious,
        session.activeQuirk?.id == BloodlineTraitId.bloodOath,
      );
    }
  }

  /// Repair only pending offers that promise vengeance without a valid target.
  /// Stable catalog order avoids rerolling heirs or consuming gameplay RNG.
  List<HeirCandidate> _restorableHeirs({required bool hasNemesis}) {
    if (hasNemesis) return List<HeirCandidate>.from(pendingHeirCandidates);
    final used = pendingHeirCandidates
        .where((heir) => heir.quirk.id != BloodlineTraitId.bloodOath)
        .map((heir) => heir.quirk.id)
        .toSet();
    final restored = <HeirCandidate>[];
    for (final heir in pendingHeirCandidates) {
      if (heir.quirk.id != BloodlineTraitId.bloodOath) {
        restored.add(heir);
        continue;
      }
      final replacement =
          BloodlineTrait.allQuirks
              .where(
                (quirk) =>
                    quirk.id != BloodlineTraitId.bloodOath &&
                    !used.contains(quirk.id),
              )
              .firstOrNull ??
          BloodlineTrait.recklessHelmsman;
      used.add(replacement.id);
      restored.add(
        HeirCandidate(
          defaultName: heir.defaultName,
          boon: heir.boon,
          quirk: replacement,
        ),
      );
    }
    return restored;
  }
}
