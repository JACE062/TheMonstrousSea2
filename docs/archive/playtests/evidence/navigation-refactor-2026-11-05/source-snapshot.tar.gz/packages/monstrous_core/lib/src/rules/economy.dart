import 'dart:math';

import '../content/consumables.dart';
import '../model/combatant.dart';
import '../model/item.dart';
import '../rng/game_rng.dart';
import '../config/voyage_economy_tuning.dart';
import '../model/material_shipment.dart';

MaterialShipment generateMaterialShipment(String id, GameRng rng, {
  required bool ketch,
  VoyageEconomyTuning tuning = VoyageEconomyTuning.provisional,
}) => MaterialShipment(
  id: id,
  seaGlass: ketch
      ? (rng.d100() <= tuning.ketchGlassChance ? rng.nextIntRange(tuning.ketchGlassMin, tuning.ketchGlassMax) : 0)
      : rng.nextIntRange(tuning.reliableGlassMin, tuning.reliableGlassMax),
  depthWroughtIron: ketch ? (rng.d100() <= tuning.ketchIronChance ? 1 : 0)
      : rng.nextIntRange(tuning.reliableIronMin, tuning.reliableIronMax),
);

/// Bounty authority for the new flow. Geometry does not affect income.
/// Titan levels overlap the next region's opening levels: map them explicitly.
int calculateVoyageVictoryGold(int encounterLevel, GameRng rng, {
  bool isApex = false, bool isTitan = false,
  VoyageEconomyTuning tuning = VoyageEconomyTuning.provisional,
}) {
  final region = ((encounterLevel - (isTitan ? 2 : 1)) ~/ 4).clamp(0, 2);
  final (low, high) = switch (region) {
    0 => (tuning.shoalsGoldMin, tuning.shoalsGoldMax),
    1 => (tuning.driftGoldMin, tuning.driftGoldMax),
    _ => (tuning.reachGoldMin, tuning.reachGoldMax),
  };
  final multiplier = isTitan ? tuning.titanMultiplier : isApex ? tuning.apexMultiplier : 1.0;
  return (rng.nextIntRange(low, high) * multiplier).round();
}

/// Generates 3-5 Tactical Belt [Consumable] items for the merchant's inventory.
///
/// Consumable potency and price are fixed across all voyage difficulties.
List<Item> generateMerchantStock(int highestDifficultyReached, GameRng rng) {
  final count = rng.nextIntRange(3, 5);
  final stock = <Item>[];

  for (var i = 0; i < count; i++) {
    final item = randomConsumable(highestDifficultyReached, rng);
    stock.add(item);
  }

  stock.sort();
  return stock;
}

/// Calculates the merchant's asking price for [item].
///
/// Standard markup is 35% above nominal sell value.
/// If [isOnSale] is true, applies a 25% discount off base value.
int getMerchantBuyPrice(Item item, {bool isOnSale = false}) {
  if (isOnSale) {
    return max(1, (item.value * 0.75).round());
  }
  return max(1, (item.value * 1.35).round());
}

/// Attempts to purchase [item] for [ship] at [price] (defaults to item.value).
///
/// Succeeds if ship has sufficient gold and available cargo hold capacity.
/// Deducts price from gold and adds item to cargo.
bool buyItem(ShipState ship, Item item, {int? price}) {
  final cost = price ?? item.value;
  if (ship.gold < cost) return false;
  if (ship.cargo.length >= ship.maxCargo) return false;

  ship.gold -= cost;
  ship.addCargo(item);
  return true;
}

/// Sells [item] from [ship]'s cargo hold.
///
/// Succeeds if [item] is in cargo. Removes item and credits [item.value] gold.
bool sellItem(ShipState ship, Item item) {
  final removed = ship.removeCargo(item);
  if (!removed) return false;

  ship.gold += item.value;
  return true;
}

/// Sells all [Treasure] items currently stored in [ship]'s cargo hold.
///
/// Removes each treasure, credits total value to [ship.gold], and returns
/// a record of `(totalGoldEarned, itemsSold)`.
(int totalGold, int itemsSold) sellAllTreasure(ShipState ship) {
  final treasures = ship.cargo.whereType<Treasure>().toList();
  if (treasures.isEmpty) return (0, 0);

  var totalGold = 0;
  for (final treasure in treasures) {
    totalGold += treasure.value;
    ship.removeCargo(treasure);
  }

  ship.gold += totalGold;
  return (totalGold, treasures.length);
}

/// Calculates the cost in gold to repair [percentage] (0.0 to 1.0) of [ship]'s max HP.
///
/// Cost is 1g per 1 HP repaired. Repair amount is capped at missing HP.
int calculateRepairCost(ShipState ship, double percentage) {
  if (percentage <= 0) return 0;
  final actual = ship.previewHealing((ship.maxHp * percentage));
  return ship.nominalHealingFor(actual);
}

/// Repairs [percentage] of [ship]'s hull at port.
///
/// Deducts the gold cost (1g per HP repaired) and restores hull points.
/// Returns false if no repair is needed or if [ship] cannot afford the cost.
bool repairShip(ShipState ship, double percentage) {
  final cost = calculateRepairCost(ship, percentage);
  if (cost <= 0) return false;
  if (ship.gold < cost) return false;

  ship.gold -= cost;
  ship.heal(cost);
  return true;
}
