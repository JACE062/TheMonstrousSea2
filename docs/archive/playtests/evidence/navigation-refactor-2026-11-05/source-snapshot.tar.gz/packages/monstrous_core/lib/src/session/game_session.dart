import 'dart:math';

import '../config/balance_config.dart';
import '../config/navigation_tuning.dart';
import '../content/consumables.dart';
import '../content/ships.dart';
import '../lore/eldritch_lore.dart';
import '../model/bloodline_trait.dart';
import '../model/combatant.dart';
import '../model/combat_presentation.dart';
import '../model/covenant_of_the_deep.dart';
import '../model/enums.dart';
import '../model/flagship_blueprint.dart';
import '../model/item.dart';
import '../model/material_shipment.dart';
import '../model/monster_intent.dart';
import '../model/nemesis.dart';
import '../model/ocean_power.dart';
import '../model/wreck_encounter.dart';
import '../persistence/profile_data.dart';
import '../rng/game_rng.dart';
import '../rules/combat.dart';
import '../rules/economy.dart';
import '../rules/lineage.dart';
import '../rules/loot.dart';
import '../rules/paid_repairs.dart';
import '../rules/monster_ai.dart';
import '../rules/sea_chart.dart';
import '../rules/shrine.dart';
import '../rules/wrecks.dart';
import '../traits/trait.dart';
import 'commands.dart';
import 'events.dart';
import 'session_phase.dart';

/// Central state machine and session orchestrator for The Monstrous Sea.
///
/// Drives the complete game loop from captain creation, naval combat,
/// spoils distribution, port economy, and multi-generational lineage.
class GameSession {
  GameSession({
    GameRng? rng,
    this.config = BalanceConfig.standard,
    NavigationTuning navigationTuning = NavigationTuning.provisional,
    ProfileData? profile,
  })  : rng = rng ?? SeededGameRng(),
        seaChart = SeaChart(rng: rng ?? SeededGameRng(), tuning: navigationTuning),
        profile = profile ?? ProfileData();

  final GameRng rng;
  final BalanceConfig config;
  final SeaChart seaChart;
  ProfileData profile;
  LineageTracker get lineage => profile.lineageTracker;

  List<HeirCandidate> pendingHeirCandidates = <HeirCandidate>[];
  BloodlineTrait? _activeBoon;
  BloodlineTrait? _activeQuirk;
  BloodlineTrait? get activeBoon => _activeBoon;
  set activeBoon(BloodlineTrait? value) {
    _activeBoon = value;
    syncCaptainTraits();
  }

  BloodlineTrait? get activeQuirk => _activeQuirk;
  set activeQuirk(BloodlineTrait? value) {
    _activeQuirk = value;
    syncCaptainTraits();
  }

  int? stormSeerRedrawRegion;
  bool isNemesisBattle = false;
  SessionPhase merchantReturnPhase = SessionPhase.port;

  SessionPhase phase = SessionPhase.captainCreation;
  String captainName = '';
  ShipState? _ship;
  ShipState? get ship => _ship;
  set ship(ShipState? value) {
    _ship = value;
    syncCaptainTraits();
  }

  /// Rebuilds derived captain stats after direct assignment or checkpoint restore.
  void syncCaptainTraits() {
    final vessel = _ship;
    if (vessel == null) return;
    _syncVesselCaptainTraits(vessel);
  }

  void _syncVesselCaptainTraits(ShipState vessel) {
    vessel.captainBoonId = _activeBoon?.id;
    vessel.captainQuirkId = _activeQuirk?.id;
    final hasBonus = _activeBoon?.id == BloodlineTraitId.quartermaster;
    if (hasBonus != vessel.captainCargoBonusApplied) {
      vessel.maxCargo += hasBonus ? 1 : -1;
      vessel.captainCargoBonusApplied = hasBonus;
    }
  }

  bool get usesLateHelm => activeQuirk?.id == BloodlineTraitId.skirmisher;
  bool get isDaredevilActive => activeQuirk?.id == BloodlineTraitId.daredevil &&
      ship != null && ship!.currentHp * 2 <= ship!.maxHp;

  /// Predictable movement before the monster responds. Hit-dependent effects
  /// such as Pin or an interrupted intent are deliberately not presumed.
  CombatRange previewResponseRange({
    HelmOrder helmOrder = HelmOrder.holdLine,
    ShipWeaponType? weaponType,
    bool utility = false,
  }) {
    final order = ship?.isGrappled == true || isImpatientCombinationPending
        ? HelmOrder.holdLine : helmOrder;
    var range = usesLateHelm ? combatRange : combatRange.rangeAfterHelmOrder(order);
    if (weaponType == ShipWeaponType.prowRam) range = CombatRange.short;
    if (weaponType == ShipWeaponType.harpoonWinch) range = range.closer;
    if (utility && ship != null && ship!.shipClass.blueprintId == BlueprintId.clipper &&
        !ship!.isGrappled) {
      range = range.farther;
    }
    return usesLateHelm ? range.rangeAfterHelmOrder(order) : range;
  }
  bool isImpatientCombinationPending = false;
  bool isImpatientRecovering = false;
  bool _hasIssuedHelmThisTurn = false;
  HelmOrder? _queuedHelmOrder;
  bool get canStartImpatientCombination =>
      phase == SessionPhase.battle &&
      activeQuirk?.id == BloodlineTraitId.impatient &&
      ship != null &&
      !isImpatientCombinationPending &&
      !isImpatientRecovering &&
      ship!.utilityCooldown == 0 &&
      ship!.equippedWeapons.any(
        (weapon) =>
            weapon.isReady &&
            isWeaponTypeUsableAtRange(weapon.weaponType, combatRange),
      );

  void _resetCombatActionStages() {
    isImpatientCombinationPending = false;
    isImpatientRecovering = false;
    _hasIssuedHelmThisTurn = false;
    _queuedHelmOrder = null;
  }

  MonsterState? currentMonster;
  CalderaClimaxChoice? calderaOutcome;
  bool hasReadCalderaOutcome = false;

  /// Persists a completed encounter without retaining a live combat object.
  bool hasDefeatedCurrentEncounter = false;
  WreckEncounter? currentWreck;
  CombatRange combatRange = CombatRange.medium;
  HelmOrder lastHelmOrderThisTurn = HelmOrder.holdLine;
  bool _disruptedBossCatastropheThisTurn = false;
  bool _purgedFrenzyThisTurn = false;
  bool usedQuickConsumableThisTurn = false;
  int quickConsumablesUsedThisTurn = 0;
  List<Item> pendingLoot = <Item>[];
  List<Item> merchantStock = <Item>[];
  MaterialShipment? merchantMaterials;
  MaterialShipment? smugglerMaterials;
  MaterialShipment? get currentMaterialShipment => phase == SessionPhase.smuggler
      ? smugglerMaterials : phase == SessionPhase.merchant ? merchantMaterials : null;
  int materialUnitPrice(TradeMaterial material) => material == TradeMaterial.seaGlass
      ? seaChart.tuning.economy.glassPrice : seaChart.tuning.economy.ironPrice;
  int? onSaleMerchantIndex;
  int lastGoldSalvaged = 0;

  /// Whether the player can still trigger a 0-turn-cost Quick Action consumable this round.
  bool get canUseQuickConsumableThisTurn =>
      phase == SessionPhase.battle && !usedQuickConsumableThisTurn;

  bool hasCareenedAtCurrentIsland = false;
  bool hasDrilledAtCurrentIsland = false;
  bool hasForagedAtCurrentIsland = false;

  /// Whether the ship is currently anchored at the grand guaranteed Midpoint Haven
  /// (as opposed to a procedural emergency secluded cove).
  bool get isCurrentIslandHaven =>
      phase == SessionPhase.respiteIsland &&
      seaChart.currentDestination == CourseDestination.midpointHaven;

  bool get isRepairRefitStop => phase == SessionPhase.respiteIsland &&
      seaChart.currentDestination == CourseDestination.repairRefit;

  bool get canUseVoyageShipwright =>
      phase == SessionPhase.stronghold || isCurrentIslandHaven || isRepairRefitStop;

  void _requireHomePort() {
    if (phase != SessionPhase.port) {
      throw StateError('Permanent progression is only available at the home port');
    }
  }

  /// Whether the crew has already spent their single shore duty at this island haven.
  bool get hasChosenIslandDuty =>
      hasCareenedAtCurrentIsland ||
      hasDrilledAtCurrentIsland ||
      hasForagedAtCurrentIsland;

  int gunneryAccuracyBoon = 0;
  int shoreDrillBoon = 0;
  PaidRepairWork paidRepairWork = PaidRepairWork();

  double? get paidRepairAllowanceFraction => phase == SessionPhase.smuggler
      ? seaChart.tuning.services.ketchPaidFraction
      : isCurrentIslandHaven ? seaChart.tuning.services.havenPaidFraction
      : isRepairRefitStop ? seaChart.tuning.services.refitPaidFraction : null;

  bool get hasPaidRepairService => phase == SessionPhase.stronghold ||
      phase == SessionPhase.smuggler || isCurrentIslandHaven || isRepairRefitStop;

  PaidRepairQuote? paidRepairQuote(double percentage, {int? normalWork}) {
    if (ship == null || !ship!.isAlive || !hasPaidRepairService) return null;
    final services = seaChart.tuning.services;
    final price = phase == SessionPhase.smuggler
        ? services.ketchGoldPerWork * (activeBoon?.id == BloodlineTraitId.smugglersKin ? 0.75 : 1)
        : services.goldPerWork * (profile.isPactActive(CovenantPactId.brittleOak) ? 1.30 : 1);
    return quotePaidRepair(ship!, paidRepairWork, percentage: percentage,
        allowanceFraction: paidRepairAllowanceFraction, goldPerWork: price, requestedWork: normalWork);
  }

  PaidRepairQuote? get affordablePaidRepairQuote {
    final full = paidRepairQuote(1);
    if (full == null || full.goldCost <= ship!.gold) return full;
    var low = 0, high = full.normalWork;
    while (low < high) {
      final middle = (low + high + 1) ~/ 2;
      final quote = paidRepairQuote(1, normalWork: middle)!;
      if (quote.goldCost <= ship!.gold) { low = middle; } else { high = middle - 1; }
    }
    return paidRepairQuote(1, normalWork: low);
  }

  /// Included in both actual shot rolls and the app's opening-shot preview.
  int get captainWeaponAccuracyModifier =>
      activeQuirk?.id == BloodlineTraitId.overzealousGunner ? -10 : 0;

  String? get stormSeerRedrawRestriction {
    if (phase != SessionPhase.helm) return 'Redraw headings from Set Course.';
    if (activeBoon?.id != BloodlineTraitId.stormSeer) {
      return 'Only a Storm-Seer can redraw headings.';
    }
    final options = seaChart.currentCourseOptions;
    if (options.any((o) => o.destination == CourseDestination.repairRefit ||
        o.destination == CourseDestination.specialistMerchant)) {
      return 'Final preparation destinations cannot be redrawn.';
    }
    if (options.length <= 1) {
      return 'This encounter has a fixed course.';
    }
    if (activeQuirk?.id == BloodlineTraitId.bloodOath &&
        options.any((option) => option.isNemesis)) {
      return 'Vendetta compels the Nemesis heading. Face it before redrawing.';
    }
    if (stormSeerRedrawRegion == seaChart.timesCompleted) {
      return 'Your redraw has already been used in this region.';
    }
    return null;
  }

  bool get canRedrawStormSeerCourses => stormSeerRedrawRestriction == null;

  /// Runic guidance is retained for every volley of the next combat.
  int runicGuidanceBoon = 0;
  String currentIslandName = '';
  String currentShipwreckName = '';
  bool hasSalvagedCurrentWreck = false;
  List<String> wreckSalvageReceipt = <String>[];

  String currentSmugglerName = '';
  List<Item> smugglerStock = <Item>[];
  bool hasClaimedSmugglerGift = false;
  bool get canClaimSmugglerGift =>
      phase == SessionPhase.smuggler &&
      activeBoon?.id == BloodlineTraitId.smugglersKin &&
      !hasClaimedSmugglerGift &&
      ship != null &&
      ship!.cargo.length < ship!.maxCargo;
  int shrineOmenSeed = 0;

  GameRng get _shrineRng => SeededGameRng(
    shrineOmenSeed +
        seaChart.timesCompleted * 100003 +
        seaChart.currentLeg * 1009,
  );
  void restoreShrineManifestations() {
    if (ship != null) {
      shrineManifestedPowers = selectShrinePowers(ship!, _shrineRng);
    }
  }

  OceanPower? get forbiddenShrinePower {
    if (activeQuirk?.id != BloodlineTraitId.superstitious ||
        shrineManifestedPowers.length < 2) {
      return null;
    }
    return shrineManifestedPowers[SeededGameRng(
      shrineOmenSeed +
          seaChart.timesCompleted * 100003 +
          seaChart.currentLeg * 1009 +
          73,
    ).nextInt(shrineManifestedPowers.length)];
  }

  String? shrineBlessingRestriction(OceanPower power, HardpointType slot) {
    if (hasCommunedAtCurrentShrine) {
      return 'The altar has already bestowed its blessing.';
    }
    if (!shrineManifestedPowers.contains(power)) {
      return 'This power has not manifested.';
    }
    if (forbiddenShrinePower == power) {
      return 'Superstitious: an ill omen forbids this power.';
    }
    if (ship == null || !canBlessHardpoint(ship!, power, slot)) {
      return 'This fitting is dedicated to another power or already sovereign.';
    }
    return null;
  }

  String currentShrineName = '';
  String currentShrineLore = '';
  bool hasCommunedAtCurrentShrine = false;
  List<OceanPower> shrineManifestedPowers = const [];

  bool get canEmergencyRepairAtSea =>
      ship != null && ship!.currentHp < (ship!.maxHp * 0.25).ceil();

  int get emergencyRepairCost => ship == null
      ? 0
      : ship!.nominalHealingFor(
              max(0, (ship!.maxHp * 0.25).ceil() - ship!.currentHp),
            ) *
            2;

  int get hullPatchHealingHp =>
      ship?.previewHealing(max(1, (ship!.maxHp * 0.30))) ?? 0;
  bool get canUseHullPatchOutsideBattle => ship?.isAlive == true && const {
    SessionPhase.port, SessionPhase.stronghold, SessionPhase.merchant,
    SessionPhase.helm, SessionPhase.loot, SessionPhase.respiteIsland,
    SessionPhase.shipwreck, SessionPhase.smuggler,
  }.contains(phase);
  int get careenHealingHp =>
      _shoreHealingHp(isCurrentIslandHaven ? seaChart.tuning.services.havenCareenFraction : seaChart.tuning.services.coveCareenFraction);
  int get wreckTimbersHealingHp => _shoreHealingHp(0.25);
  int _shoreHealingHp(double fraction) {
    if (ship == null) return 0;
    var nominal = (ship!.maxHp * fraction);
    if (profile.isPactActive(CovenantPactId.brittleOak)) {
      nominal *= 0.75;
    }
    return ship!.previewHealing(nominal);
  }

  int _repairNominal(double percentage) {
    if (ship == null || percentage <= 0) return 0;
    final desired =
        (phase == SessionPhase.restArea || phase == SessionPhase.helm)
        ? max(0, (ship!.maxHp * 0.25).ceil() - ship!.currentHp)
        : ship!.previewHealing((ship!.maxHp * percentage));
    return ship!.nominalHealingFor(desired);
  }

  int repairHpFor(double percentage) => (phase == SessionPhase.restArea || phase == SessionPhase.helm)
      ? ship == null ? 0 : ship!.previewHealing(_repairNominal(percentage))
      : paidRepairQuote(percentage)?.restoredHp ?? 0;
  int repairCostFor(double percentage) {
    if (hasPaidRepairService) return paidRepairQuote(percentage)?.goldCost ?? 0;
    if (phase == SessionPhase.restArea || phase == SessionPhase.helm) return _repairNominal(percentage) * 2;
    return 0;
  }

  bool get isRegionBossEncounter =>
      currentMonster != null && (seaChart.isRegionTitan);

  bool get isExpeditionWon => phase == SessionPhase.expeditionVictory;

  int monstersDefeatedThisLife = 0;
  int highestDifficultyThisLife = 0;
  int battleRound = 0;

  /// Returns the current asking price for the item at [stockIndex] in the shop.
  int getMerchantAskingPrice(int stockIndex) {
    if (stockIndex < 0 || stockIndex >= merchantStock.length) return 0;
    return getMerchantBuyPrice(
      merchantStock[stockIndex],
      isOnSale: stockIndex == onSaleMerchantIndex,
    );
  }

  /// Refreshes the merchant's wares and randomly designates one item as on-sale.
  void refreshMerchantStock([int? difficulty, bool voyageMaterials = false]) {
    final diff = difficulty ?? highestDifficultyThisLife;
    merchantStock = generateMerchantStock(max(1, diff), rng);
    merchantMaterials = voyageMaterials ? generateMaterialShipment(
      '$shrineOmenSeed:${seaChart.timesCompleted}:${seaChart.currentLeg}:merchant', rng,
      ketch: false, tuning: seaChart.tuning.economy) : null;
    onSaleMerchantIndex =
        merchantStock.isNotEmpty ? rng.nextInt(merchantStock.length) : null;
  }

  final List<CombatTrait> traits = const <CombatTrait>[
    FortifyTrait(),
    EvasionTrait(),
    InkCloudTrait(),
    TentacleTrait(),
    CarapaceTrait(),
    SharkFrenzyTrait(),
    SerpentSlitherTrait(),
  ];

  /// Dispatches [command] to update session state and returns resulting events.
  List<GameEvent> dispatch(Command command) {
    final wasBattle = phase == SessionPhase.battle;
    final events = <GameEvent>[..._dispatchCommand(command)];
    if (wasBattle && phase == SessionPhase.battle) {
      // Covers decision-boundary expiry/cleanup without revealing final health,
      // shell or limb counts ahead of their individual outcome events.
      events.add(CombatEffectsChanged.capture(ship!));
      events.add(CombatEffectsChanged.capture(currentMonster!));
    }
    return events;
  }

  List<GameEvent> _dispatchCommand(Command command) {
    return switch (command) {
      AcknowledgeCalderaOutcome() => _handleAcknowledgeCalderaOutcome(),
      NameCaptain(:final name) => _handleNameCaptain(name),
      ChooseShip(:final shipClass, :final customName) =>
        _handleChooseShip(shipClass, customName),
      BeginFirstVoyage(:final captainName, :final customShipName) =>
        _handleBeginFirstVoyage(captainName, customShipName),
      VentureOutToSea(:final startingRow) => _handleVentureOutToSea(
        startingRow,
      ),
      FireWeaponVolley(:final weaponType) => _handleFireWeaponVolley(
        weaponType,
      ),
      IssueHelmOrder(:final order) => _handleIssueHelmOrder(order),
      ChangeCombatRange(:final targetRange) => _handleChangeCombatRange(
        targetRange,
      ),
      UseConsumableItem(:final cargoIndex) => _handleUseConsumable(cargoIndex),
      UseHullPatchKit(:final itemId, :final fromPendingLoot) => _handleUseHullPatchKit(itemId, fromPendingLoot: fromPendingLoot),
      ExecuteShipSpecialAction(:final borrowNextAction) =>
        _handleShipSpecialAction(borrowNextAction: borrowNextAction),
      ClaimSmugglerGift(:final stockIndex) => _handleClaimSmugglerGift(
        stockIndex,
      ),
      BraceForImpact() => _handleBraceForImpact(),
      TakeLootItem(:final lootIndex) => _handleTakeLootItem(lootIndex),
      TakeAllLoot() => _handleTakeAllLoot(),
      LeaveRemainingLoot() => _handleLeaveRemainingLoot(),
      DropCargoItem(:final cargoIndex) => _handleDropCargo(cargoIndex),
      EquipCargoWeapon(:final cargoIndex) => _handleEquipCargoWeapon(cargoIndex),
      UnequipShipWeapon(:final equippedIndex) =>
        _handleUnequipShipWeapon(equippedIndex),
      AdvanceToNextBattle() => _handleAdvanceToNextBattle(),
      ReturnToPort() => _handleReturnToPort(),
      VisitMerchant() => _handleVisitMerchant(),
      LeaveMerchant() => _handleLeaveMerchant(),
      BuyMerchantItem(:final stockIndex) => _handleBuyMerchantItem(stockIndex),
      BuyMerchantMaterial(:final shipmentId, :final material, :final quantity) =>
        _handleBuyMerchantMaterial(shipmentId, material, quantity),
      SellCargoItem(:final cargoIndex) => _handleSellCargoItem(cargoIndex),
      SellAllTreasure() => _handleSellAllTreasure(),
      RepairShip(:final percentage) => _handleRepairShip(percentage),
      BuyAffordablePaidRepairs() => _handleAffordablePaidRepairs(),
      UpgradeShip() => _handleUpgradeShip(),
      TemperHardpoint(:final slot) => _handleTemperHardpoint(slot),
      ContinueLineage(
        :final heirName,
        :final chosenClass,
        :final boon,
        :final quirk,
      ) =>
        _handleContinueLineage(heirName, chosenClass, boon: boon, quirk: quirk),
      AbandonHunt() => _handleAbandonHunt(),
      CareenHullAtIsland() => _handleCareenHullAtIsland(),
      DrillGunnersAtIsland() => _handleDrillGunnersAtIsland(),
      ForageShoalsAtIsland() => _handleForageShoalsAtIsland(),
      DepartIsland() => _handleDepartIsland(),
      SalvageShipwreck(:final choice) => _handleSalvageShipwreck(choice),
      ChooseWreckRecovery(:final wreckId, :final choice) => _handleChooseWreckRecovery(wreckId, choice),
      ClaimExpeditionVictory() => _handleClaimExpeditionVictory(),
      ResolveCalderaClimax(:final choice) => _handleResolveCalderaClimax(choice),
      ToggleCovenantPact(:final pactId) => _handleToggleCovenantPact(pactId),
      UpgradeBlueprintArmament(:final blueprintId) =>
        _handleUpgradeBlueprintArmament(blueprintId),
      UnlockAuxiliaryExpansion() => _handleUnlockAuxiliaryExpansion(),
      UnlockEldritchRelic(:final relicId) => _handleUnlockEldritchRelic(relicId),
      UpgradeHarborMonument(:final monumentId) =>
        _handleUpgradeHarborMonument(monumentId),
      CommuneWithShrine(:final choice) => _handleCommuneWithShrine(choice),
      AcceptShrineBlessing(:final power, :final slot) =>
        _handleAcceptShrineBlessing(power, slot),
      DepartShrine() => _handleDepartShrine(),
      DepartSmuggler() => _handleDepartSmuggler(),
      SteerCourse(:final bearing) => _handleSteerCourse(bearing),
      RedrawStormSeerCourses() => _handleRedrawStormSeerCourses(),
      TakeHelm() => _handleTakeHelm(),
      UnlockBlueprint(:final blueprintId) => _handleUnlockBlueprint(blueprintId),
      CommissionBlueprint(:final blueprintId) =>
        _handleCommissionBlueprint(blueprintId),
    };
  }

  List<GameEvent> _handleNameCaptain(String name) {
    if (phase != SessionPhase.captainCreation &&
        phase != SessionPhase.death) {
      throw StateError('Cannot name captain in phase $phase');
    }
    captainName = name;

    // Davy Jones Easter Egg
    if (name.equalsIgnoreCase('Davy Jones')) {
      profile.hasBegunFirstVoyage = true;
      final events = <GameEvent>[];
      ship = createFlyingDutchman();
      seaChart.currentRow = 3;
      seaChart.currentCol = 4;
      seaChart.maxRowReached = 3;
      currentMonster = seaChart.currentMonster(rng);
      battleRound = 1;
      combatRange = CombatRange.medium;
      lastHelmOrderThisTurn = HelmOrder.holdLine;
      _disruptedBossCatastropheThisTurn = false;
      usedQuickConsumableThisTurn = false;
      quickConsumablesUsedThisTurn = 0;
      currentMonster!.currentIntent = selectNextMonsterIntent(
        currentMonster!,
        combatRange,
        rng,
        battleRound: battleRound,
      );
      final prevPhase = phase.displayName;
      phase = SessionPhase.battle;

      events.add(PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ));
      events.add(BattleStarted(
        monsterName: currentMonster!.name,
        difficulty: seaChart.currentDifficulty,
        isBoss: true,
        monsterHp: currentMonster!.maxHp,
        monsterAc: currentMonster!.armorClass,
      ));
      events.add(MonsterIntentTelegraphed(
        monsterName: currentMonster!.name,
        intent: currentMonster!.currentIntent!,
      ));
      return events;
    }

    return const <GameEvent>[];
  }

  List<GameEvent> _handleChooseShip(ShipClass shipClass, String? customName) {
    if (phase != SessionPhase.captainCreation) {
      throw StateError('Cannot choose starting ship in phase $phase');
    }
    final bpId = BlueprintId.fromShipClass(shipClass);
    if (!profile.isBlueprintUnlocked(bpId)) {
      throw StateError('Blueprint $bpId is not unlocked');
    }
    ship = createFlagshipFromBlueprint(
      bpId,
      level: 1,
      rng: rng,
      name: (customName != null && customName.isNotEmpty) ? customName : null,
      armamentTier: profile.armamentTierFor(bpId),
      hasExpandedAuxiliarySlot: profile.hasExpandedAuxiliarySlot,
      bonusMaxHp: profile.monumentBonusMaxHp,
    );
    ship!.shipClass = shipClass;
    if (shipClass == ShipClass.corvette) {
      ship!.maxWeaponWeight = 5;
      ship!.baseEvasion = 10;
      ship!.currentEvasion = 10;
    }
    profile.activeBlueprintId = bpId.name;
    ship!.gold = 25;

    refreshMerchantStock(1);
    final prevPhase = phase.displayName;
    phase = SessionPhase.port;

    return <GameEvent>[
      PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ),
    ];
  }

  List<GameEvent> _handleBeginFirstVoyage(String name, String? shipName) {
    if (phase != SessionPhase.captainCreation) {
      throw StateError('Cannot begin a first voyage in phase $phase');
    }
    if (name.trim().isEmpty) {
      throw ArgumentError('Captain name cannot be empty');
    }
    final events = <GameEvent>[..._handleNameCaptain(name.trim())];
    if (phase == SessionPhase.battle) return events; // Davy Jones.
    events.addAll(_handleChooseShip(ShipClass.standard, shipName));
    events.addAll(_handleVentureOutToSea());
    return events;
  }

  List<GameEvent> _handleUnlockBlueprint(BlueprintId blueprintId) {
    _requireHomePort();
    final bp = FlagshipBlueprint.catalog[blueprintId];
    if (bp == null) {
      throw ArgumentError('Unknown blueprint: $blueprintId');
    }
    if (profile.isBlueprintUnlocked(blueprintId)) {
      return const <GameEvent>[];
    }
    if (!profile.canUnlockBlueprint(blueprintId)) {
      throw StateError('Cannot afford blueprint $blueprintId');
    }
    profile.unlockBlueprint(blueprintId);
    return <GameEvent>[
      BlueprintUnlocked(
        blueprintId: blueprintId,
        blueprintName: bp.name,
        remainingCurrencies: profile.metaInventory,
      ),
    ];
  }

  List<GameEvent> _handleCommissionBlueprint(BlueprintId blueprintId) {
    if (phase != SessionPhase.port && phase != SessionPhase.captainCreation) {
      throw StateError('Cannot commission blueprints in phase $phase');
    }
    final bp = FlagshipBlueprint.catalog[blueprintId];
    if (bp == null) {
      throw ArgumentError('Unknown blueprint: $blueprintId');
    }
    if (!profile.isBlueprintUnlocked(blueprintId)) {
      throw StateError('Blueprint $blueprintId is not unlocked');
    }
    profile.activeBlueprintId = blueprintId.name;

    final oldGold = ship?.gold ?? 25;
    final oldName = (ship != null && ship!.name.isNotEmpty)
        ? ship!.name
        : (captainName.isNotEmpty ? '$captainName\'s Flagship' : null);
    final oldCargo =
        ship?.cargo != null ? List<Item>.from(ship!.cargo) : <Item>[];

    final newShip = createFlagshipFromBlueprint(
      blueprintId,
      level: 1,
      rng: rng,
      name: oldName,
      armamentTier: profile.armamentTierFor(blueprintId),
      hasExpandedAuxiliarySlot: profile.hasExpandedAuxiliarySlot,
      bonusMaxHp: profile.monumentBonusMaxHp,
    );
    newShip.gold = oldGold;
    newShip.blessings.addAll(ship?.blessings ?? {});
    _syncVesselCaptainTraits(newShip);

    for (final item in oldCargo) {
      if (item is ShipWeapon) continue;
      newShip.addCargo(item);
    }

    ship = newShip;

    return <GameEvent>[
      BlueprintCommissioned(
        blueprintId: blueprintId,
        blueprintName: bp.name,
        ship: newShip,
      ),
    ];
  }

  List<GameEvent> _handleToggleCovenantPact(CovenantPactId pactId) {
    if (phase != SessionPhase.port) {
      throw StateError('Can only modify Covenant Pacts while at Port');
    }
    if (!profile.hasUnlockedCovenant) {
      throw StateError('Covenant of the Deep has not been unlocked yet');
    }
    profile.togglePact(pactId);
    final isActive = profile.isPactActive(pactId);
    final pact = CovenantPact.catalog[pactId]!;
    return <GameEvent>[
      CovenantPactToggled(
        pactId: pactId,
        isActive: isActive,
        totalPactBurden: profile.totalPactBurden,
      ),
      NarrationEvent(
        isActive
            ? 'Covenant Pact ratified: ${pact.name} (+${pact.burden} Pact Burden).'
            : 'Covenant Pact rescinded: ${pact.name}.',
      ),
    ];
  }

  List<GameEvent> _handleUpgradeBlueprintArmament(BlueprintId blueprintId) {
    _requireHomePort();
    if (!profile.canUpgradeBlueprintArmament(blueprintId)) {
      throw StateError('Cannot upgrade armament for $blueprintId');
    }
    profile.upgradeBlueprintArmament(blueprintId);
    final newTier = profile.armamentTierFor(blueprintId);
    if (ship != null && ship!.blueprintId == blueprintId.name) {
      // Refresh signature weapon tier on the active flagship
      final mult = BlueprintArmamentProgression.damageMultiplierForTier(newTier);
      final prevMult =
          BlueprintArmamentProgression.damageMultiplierForTier(newTier - 1);
      final numeral = newTier == 2 ? 'II' : 'III';
      for (final w in ship!.equippedWeapons) {
        if (w.isSignature || blueprintId == BlueprintId.standard) {
          w.damage = ((w.damage / prevMult) * mult).round();
          final baseName = w.name.replaceAll(RegExp(r' (II|III)$'), '');
          w.name = '$baseName $numeral';
        }
      }
    }
    final bp = FlagshipBlueprint.catalog[blueprintId]!;
    return <GameEvent>[
      BlueprintArmamentUpgraded(blueprintId: blueprintId, newTier: newTier),
      NarrationEvent(
        '${bp.name} signature armament upgraded to Tier $newTier!',
      ),
    ];
  }

  List<GameEvent> _handleUnlockAuxiliaryExpansion() {
    _requireHomePort();
    if (!profile.canUnlockAuxiliaryExpansion()) {
      throw StateError('Cannot unlock Reserve Auxiliary Fitting expansion');
    }
    profile.unlockAuxiliaryExpansion();
    if (ship != null) {
      ship!.maxCargo += 1;
      ship!.maxWeaponWeight += 2;
    }
    return const <GameEvent>[
      AuxiliaryExpansionUnlocked(),
      NarrationEvent(
        'Tactical Belt expanded (+1 Slot)!',
      ),
    ];
  }

  List<GameEvent> _handleUnlockEldritchRelic(EldritchRelicId relicId) {
    _requireHomePort();
    if (!profile.canUnlockEldritchRelic(relicId)) {
      throw StateError('Cannot unlock Eldritch Relic $relicId');
    }
    profile.unlockEldritchRelic(relicId);
    final def = EldritchRelicDef.catalog[relicId]!;
    return <GameEvent>[
      EldritchRelicUnlocked(relicId: relicId, relicName: def.name),
      NarrationEvent(
        'Forged Eldritch Relic at the Covenant Altar: ${def.name}!',
      ),
    ];
  }

  List<GameEvent> _handleUpgradeHarborMonument(HarborMonumentId monumentId) {
    _requireHomePort();
    if (!profile.canUpgradeMonument(monumentId)) {
      throw StateError('Cannot upgrade Harbor Monument $monumentId');
    }
    profile.upgradeMonument(monumentId);
    final newRank = profile.monumentRank(monumentId);
    if (monumentId == HarborMonumentId.obsidianObelisk && ship != null) {
      ship!.maxHp += 5;
      ship!.currentHp += 5;
    }
    final def = HarborMonumentDef.catalog[monumentId]!;
    return <GameEvent>[
      HarborMonumentUpgraded(monumentId: monumentId, newRank: newRank),
      NarrationEvent(
        '${def.name} consecrated to Rank $newRank (${def.bonusPerRankDescription})!',
      ),
    ];
  }

  List<GameEvent> _handleVentureOutToSea([int startingRow = 0]) {
    if (phase == SessionPhase.stronghold) return _handleTakeHelm();
    if (phase != SessionPhase.port) {
      throw StateError('Cannot venture out to sea from $phase');
    }
    final clampedRow = startingRow.clamp(0, seaChart.maxRowReached);
    profile.hasBegunFirstVoyage = true;
    _resetVoyageRefits();
    // A departure from port begins a fresh voyage; blessings are run-scoped.
    ship?.blessings.clear();
    gunneryAccuracyBoon = 0;
    shoreDrillBoon = 0;
    runicGuidanceBoon = 0;
    shrineManifestedPowers = const [];
    stormSeerRedrawRegion = null;
    shrineOmenSeed = rng.nextInt(1 << 30);
    _resetCombatActionStages();
    syncCaptainTraits();
    seaChart.beginVoyage(startingRow: clampedRow);
    return _startEncounter();
  }

  void _resetVoyageRefits() {
    final vessel = ship;
    if (vessel == null || captainName.equalsIgnoreCase('Davy Jones') ||
        (vessel.level == 1 && vessel.hardpointMarks.values.every((mark) => mark == 1))) {
      return;
    }
    final blueprint = BlueprintId.fromShipClass(vessel.shipClass);
    final base = createFlagshipFromBlueprint(blueprint, rng: rng,
        id: vessel.id, name: vessel.name,
        armamentTier: profile.armamentTierFor(blueprint),
        hasExpandedAuxiliarySlot: profile.hasExpandedAuxiliarySlot,
        bonusMaxHp: profile.monumentBonusMaxHp);
    // Gold and cargo belong to the captain. Only temporary ship refits reset.
    vessel
      ..level = 1
      ..maxHp = base.maxHp
      ..currentHp = base.maxHp
      ..armorClass = base.armorClass
      ..captainCargoBonusApplied = false
      ..maxCargo = base.maxCargo
      ..maxWeaponWeight = base.maxWeaponWeight
      ..baseEvasion = base.baseEvasion
      ..baseDmgReduction = base.baseDmgReduction
      ..dmgReductionMod = base.dmgReductionMod;
    vessel.hardpointMarks..clear()..addAll(base.hardpointMarks);
    vessel.equippedWeapons..clear()..addAll(base.equippedWeapons);
  }

  List<GameEvent> _handleAdvanceToNextBattle() {
    if (phase == SessionPhase.stronghold) return _handleTakeHelm();
    if (phase == SessionPhase.helm) {
      final offered = seaChart.ensureCourseOptions(rng, profile.activeNemesis,
          profile.isPactActive(CovenantPactId.chokingFog),
          profile.isPactActive(CovenantPactId.apexEmergence),
          activeQuirk?.id == BloodlineTraitId.superstitious,
          activeQuirk?.id == BloodlineTraitId.bloodOath);
      final available = offered.where((o) => courseRestriction(o.bearing) == null);
      final chosen = available.where((o) => o.bearing == NavigationalBearing.deadAhead).firstOrNull
          ?? available.first;
      return _handleSteerCourse(chosen.bearing);
    }
    if (phase == SessionPhase.smuggler) {
      return _handleDepartSmuggler();
    }
    if (phase == SessionPhase.shrine) {
      return _handleDepartShrine();
    }
    if (phase != SessionPhase.restArea && phase != SessionPhase.shipwreck) {
      throw StateError('Cannot advance to next battle from $phase');
    }
    if (phase == SessionPhase.shipwreck && pendingLoot.isNotEmpty) {
      throw StateError('Stow or leave the remaining wreck supplies before departing');
    }
    if (phase == SessionPhase.shipwreck &&
        (currentWreck != null ? !currentWreck!.isSettled : !hasSalvagedCurrentWreck)) {
      throw StateError(
          'Resolve the current wreck or choose an empty pass-by before departing');
    }

    // Check if we just defeated the Region Boss at [3][4] or leg totalLegs
    if (phase == SessionPhase.restArea &&
        seaChart.isRegionTitan &&
        (hasDefeatedCurrentEncounter || currentMonster?.isAlive == false)) {
      if (seaChart.currentRegionIndex >= SeaChart.totalRegions - 1) {
        // Slain the Region 3 Final Titan! Grand Victory!
        final prevPhase = phase.displayName;
        phase = SessionPhase.expeditionVictory;
        return <GameEvent>[
          PhaseChanged(
            previousPhase: prevPhase,
            newPhase: phase.displayName,
          ),
          ExpeditionWon(
            captainName: captainName,
            shipName: ship!.name,
            monstersDefeated: monstersDefeatedThisLife,
            goldAmassed: ship!.gold,
          ),
        ];
      } else {
        // Transition to next region via after-region stronghold!
        final prevRegion = seaChart.currentRegionName;
        seaChart.advanceRegion(rng);
        paidRepairWork = PaidRepairWork();
        final nextRegion = seaChart.currentRegionName;
        final stronghold = seaChart.currentPortName;
        refreshMerchantStock(seaChart.currentDifficulty, true);

        final prevPhase = phase.displayName;
        phase = SessionPhase.stronghold;
        return <GameEvent>[
          RegionTransitioned(
            previousRegion: prevRegion,
            newRegion: nextRegion,
            narrative:
                'The titan sinks into the deep! The passage clears, and your ship makes berth at $stronghold, fortified gateway to $nextRegion.',
          ),
          PhaseChanged(
            previousPhase: prevPhase,
            newPhase: phase.displayName,
          ),
        ];
      }
    }

    final events = _handleTakeHelm();
    if (phase == SessionPhase.helm) {
      final options = seaChart.currentCourseOptions;
      final compelledNemesis = activeQuirk?.id == BloodlineTraitId.bloodOath
          ? options.where((option) => option.isNemesis).firstOrNull
          : null;
      final bearing =
          compelledNemesis?.bearing ??
          (activeQuirk?.id == BloodlineTraitId.recklessHelmsman &&
                  options.length > 1
              ? options
                    .firstWhere(
                      (o) => o.bearing != NavigationalBearing.deadAhead,
                    )
                    .bearing
              : options.any((o) => o.bearing == NavigationalBearing.deadAhead)
                  ? NavigationalBearing.deadAhead : options.first.bearing);
      events.addAll(_handleSteerCourse(bearing));
    }
    return events;
  }

  List<GameEvent> _handleTakeHelm() {
    if (phase != SessionPhase.restArea &&
        phase != SessionPhase.respiteIsland &&
        phase != SessionPhase.shipwreck &&
        phase != SessionPhase.smuggler &&
        phase != SessionPhase.shrine &&
        phase != SessionPhase.port &&
        phase != SessionPhase.stronghold &&
        !(phase == SessionPhase.merchant && merchantReturnPhase == SessionPhase.helm)) {
      throw StateError('Cannot take helm from phase $phase');
    }
    if (phase == SessionPhase.port) {
      _resetVoyageRefits();
      ship?.blessings.clear();
      gunneryAccuracyBoon = 0;
      shoreDrillBoon = 0;
      runicGuidanceBoon = 0;
      shrineManifestedPowers = const [];
      stormSeerRedrawRegion = null;
      shrineOmenSeed = rng.nextInt(1 << 30);
      _resetCombatActionStages();
      syncCaptainTraits();
    }
    if (phase == SessionPhase.shipwreck && pendingLoot.isNotEmpty) {
      throw StateError('Stow or leave the remaining wreck supplies before departing');
    }
    if (phase == SessionPhase.shipwreck &&
        (currentWreck != null ? !currentWreck!.isSettled : !hasSalvagedCurrentWreck)) {
      throw StateError(
          'Resolve the current wreck or choose an empty pass-by before departing');
    }

    // Check if we just defeated the Region Boss at [3][4] or leg totalLegs
    if ((phase == SessionPhase.restArea || phase == SessionPhase.loot) &&
        seaChart.isRegionTitan &&
        (hasDefeatedCurrentEncounter || currentMonster?.isAlive == false)) {
      if (seaChart.currentRegionIndex >= SeaChart.totalRegions - 1) {
        final prevPhase = phase.displayName;
        phase = SessionPhase.expeditionVictory;
        return <GameEvent>[
          PhaseChanged(
            previousPhase: prevPhase,
            newPhase: phase.displayName,
          ),
          ExpeditionWon(
            captainName: captainName,
            shipName: ship!.name,
            monstersDefeated: monstersDefeatedThisLife,
            goldAmassed: ship!.gold,
          ),
        ];
      } else {
        final prevRegion = seaChart.currentRegionName;
        seaChart.advanceRegion(rng);
        paidRepairWork = PaidRepairWork();
        final nextRegion = seaChart.currentRegionName;
        final stronghold = seaChart.currentPortName;
        refreshMerchantStock(seaChart.currentDifficulty, true);

        final prevPhase = phase.displayName;
        phase = SessionPhase.stronghold;
        return <GameEvent>[
          RegionTransitioned(
            previousRegion: prevRegion,
            newRegion: nextRegion,
            narrative:
                'The titan sinks into the deep! The passage clears, and your ship makes berth at $stronghold, fortified gateway to $nextRegion.',
          ),
          PhaseChanged(
            previousPhase: prevPhase,
            newPhase: phase.displayName,
          ),
        ];
      }
    }

    final prevPhase = phase.displayName;
    phase = SessionPhase.helm;
    final courses = seaChart.ensureCourseOptions(
      rng,
      profile.activeNemesis,
      profile.isPactActive(CovenantPactId.chokingFog),
      profile.isPactActive(CovenantPactId.apexEmergence),
      activeQuirk?.id == BloodlineTraitId.superstitious,
      activeQuirk?.id == BloodlineTraitId.bloodOath,
    );
    return <GameEvent>[
      PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ),
      HelmApproached(
        currentLeg: seaChart.currentLeg,
        totalLegs: seaChart.totalLegs,
        regionName: seaChart.currentRegionName,
        availableCourses: courses,
      ),
    ];
  }

  List<GameEvent> _handleSteerCourse(NavigationalBearing bearing) {
    if (phase != SessionPhase.helm) {
      throw StateError('Cannot steer course from phase $phase');
    }

    // Also support restored/legacy helm states with no cached offers. Never
    // let SeaChart's context-free fallback generate a session's course choices.
    seaChart.ensureCourseOptions(
      rng,
      profile.activeNemesis,
      profile.isPactActive(CovenantPactId.chokingFog),
      profile.isPactActive(CovenantPactId.apexEmergence),
      activeQuirk?.id == BloodlineTraitId.superstitious,
      activeQuirk?.id == BloodlineTraitId.bloodOath,
    );

    final restriction = courseRestriction(bearing);
    if (restriction != null) throw StateError(restriction);

    final chosen = seaChart.steerCourse(bearing, rng);
    profile.hasBegunFirstVoyage = true;
    final events = <GameEvent>[
      CourseSteered(
        bearing: bearing,
        nodeType: chosen.nodeType,
        leg: seaChart.currentLeg,
        lookoutCall: chosen.lookoutCall,
      ),
    ];

    events.addAll(_startEncounter());
    return events;
  }

  List<GameEvent> _handleRedrawStormSeerCourses() {
    final restriction = stormSeerRedrawRestriction;
    if (restriction != null) throw StateError(restriction);
    seaChart.redrawOrdinaryCourses(
      rng,
      profile.activeNemesis,
      profile.isPactActive(CovenantPactId.chokingFog),
      profile.isPactActive(CovenantPactId.apexEmergence),
      activeQuirk?.id == BloodlineTraitId.superstitious,
    );
    stormSeerRedrawRegion = seaChart.timesCompleted;
    return const [
      NarrationEvent(
        'Storm-Seer reads a change in the winds. Ordinary headings are redrawn; '
        'the voyage stays on its current leg.',
      ),
    ];
  }

  /// Shared course lock explanation for presentation and engine validation.
  /// Single-heading Haven/Titan approaches remain reachable.
  String? courseRestriction(NavigationalBearing bearing) {
    // Reckless Helmsman: "Dead Ahead" heading is disabled at sea
    if (activeQuirk?.id == BloodlineTraitId.recklessHelmsman &&
        bearing == NavigationalBearing.deadAhead &&
        seaChart.currentCourseOptions.length > 1) {
      return 'Reckless Helmsman refuses to steer Dead Ahead!';
    }

    // Blood Oath: If Nemesis is visible on the helm, wheel locks onto it
    if (activeQuirk?.id == BloodlineTraitId.bloodOath) {
      final nemesisCourse = seaChart.currentCourseOptions
          .where((opt) => opt.isNemesis)
          .firstOrNull;
      if (nemesisCourse != null && bearing != nemesisCourse.bearing) {
        return 'Blood Oath compels the wheel: you cannot steer away from your Nemesis!';
      }
    }

    return null;
  }

  List<GameEvent> _startEncounter() {
    hasDefeatedCurrentEncounter = false;
    currentMonster = null;
    currentWreck = null;
    paidRepairWork = PaidRepairWork();
    _resetCombatActionStages();
    if (ship == null || !ship!.isAlive) {
      return _resolvePlayerDeath();
    }
    ship!.resetCombatBoosts();
    ship!.resetWeaponCooldowns();
    _purgedFrenzyThisTurn = false;

    final events = <GameEvent>[];

    final nodeType = seaChart.currentNodeType;
    if (seaChart.currentDestination == CourseDestination.specialistMerchant) {
      refreshMerchantStock(seaChart.currentDifficulty, true);
      merchantReturnPhase = SessionPhase.helm;
      final previous = phase.displayName;
      phase = SessionPhase.merchant;
      return [PhaseChanged(previousPhase: previous, newPhase: phase.displayName)];
    }
    if (nodeType == EncounterNodeType.respiteIsland) {
      hasCareenedAtCurrentIsland = false;
      hasDrilledAtCurrentIsland = false;
      hasForagedAtCurrentIsland = false;
      final isHaven = seaChart.currentDestination == CourseDestination.midpointHaven;
      final isRefit = seaChart.currentDestination == CourseDestination.repairRefit;
      currentIslandName = isRefit ? 'Final Preparation Shipwright' : isHaven
          ? switch (seaChart.currentRegionIndex) {
              0 => "The Siren's Rest Haven",
              1 => "Sargasso Sanctuary Key",
              _ => "Caldera Refuge Atoll",
            }
          : _generateIslandName();
      final prevPhase = phase.displayName;
      phase = SessionPhase.respiteIsland;
      events.add(PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ));
      events.add(RespiteIslandReached(
        islandName: currentIslandName,
        description: isRefit ? 'Paid repairs and voyage refits before the Titan. No free shore activity.' : isHaven
            ? 'A grand fortified haven with calm deep-water berths, freshwater springs, and traveling shipwrights.'
            : 'A secluded sandy atoll with calm surf, where seabirds wheel overhead offering emergency respite.',
      ));
      return events;
    }

    if (nodeType == EncounterNodeType.shipwreckSalvage) {
      hasSalvagedCurrentWreck = false;
      wreckSalvageReceipt = <String>[];
      pendingLoot.clear();
      currentShipwreckName = _generateShipwreckName();
      currentWreck = WreckEncounter(
        id: '$shrineOmenSeed:${seaChart.timesCompleted}:${seaChart.currentLeg}',
        sighting: seaChart.currentWreckSighting ?? generateWreckSighting(rng, seaChart.tuning.wrecks),
      );
      final prevPhase = phase.displayName;
      phase = SessionPhase.shipwreck;
      events.add(PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ));
      events.add(ShipwreckDiscovered(
        shipwreckName: currentShipwreckName,
        description:
            currentWreck!.sighting.clue,
      ));
      if (wreckApproachAmbush(currentWreck!, seaChart.tuning.wrecks)) {
        events.addAll(_startWreckBattle(approach: true));
      }
      return events;
    }

    if (nodeType == EncounterNodeType.smugglerTrader) {
      hasClaimedSmugglerGift = false;
      currentSmugglerName = _generateSmugglerName();
      smugglerStock = generateMerchantStock(max(1, seaChart.currentDifficulty + 1), rng);
      smugglerMaterials = generateMaterialShipment(
        '$shrineOmenSeed:${seaChart.timesCompleted}:${seaChart.currentLeg}:ketch', rng,
        ketch: true, tuning: seaChart.tuning.economy);
      final prevPhase = phase.displayName;
      phase = SessionPhase.smuggler;
      events.add(PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ));
      events.add(SmugglerEncountered(
        smugglerName: currentSmugglerName,
        description:
            'A clandestine merchant ketch riding the ocean swells under muffled lanterns, peddling contraband munitions.',
      ));
      return events;
    }

    if (nodeType == EncounterNodeType.ancientShrine) {
      hasCommunedAtCurrentShrine = false;
      currentShrineName = _generateShrineName();
      currentShrineLore = _generateShrineLore();
      shrineManifestedPowers = selectShrinePowers(ship!, _shrineRng);
      final prevPhase = phase.displayName;
      phase = SessionPhase.shrine;
      events.add(PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ));
      events.add(ShrineDiscovered(
        shrineName: currentShrineName,
        loreInscription: currentShrineLore,
      ));
      return events;
    }

    if (seaChart.currentIsNemesis && profile.activeNemesis != null) {
      return _startBattle(profile.activeNemesis!.instantiateMonster(rng), nemesisBattle: true);
    }
    return _startBattle(seaChart.currentMonster(rng));
  }

  List<GameEvent> _startBattle(MonsterState monster, {bool nemesisBattle = false}) {
    hasDefeatedCurrentEncounter = false;
    _resetCombatActionStages();
    ship!.resetCombatBoosts();
    ship!.resetWeaponCooldowns();
    _purgedFrenzyThisTurn = false;
    currentMonster = monster;
    isNemesisBattle = nemesisBattle;
    final events = <GameEvent>[];
    battleRound = 1;
    combatRange = CombatRange.medium;

    // Apply Covenant of the Deep Pacts to the spawned monster:
    if (profile.isPactActive(CovenantPactId.abyssalVigor)) {
      currentMonster!.maxHp = (currentMonster!.maxHp * 1.25).round();
      currentMonster!.currentHp = currentMonster!.maxHp;
    }
    if (profile.isPactActive(CovenantPactId.calcifiedCarapace)) {
      currentMonster!.maxCarapace += 10;
      currentMonster!.carapacePlating += 10;
    }
    if (profile.isPactActive(CovenantPactId.feedingFrenzy)) {
      for (final mw in currentMonster!.usableWeapons) {
        mw.damage = (mw.damage * 1.15).round();
      }
    }

    // Environmental Hazards by Region:
    if (seaChart.currentRegionIndex == 1) {
      // Region 2: The Sargasso Drift
      // Tangled Kelp slows ship maneuvering (-10% evasion, or -20% under Volatile Environs)
      final kelpPenalty =
          profile.isPactActive(CovenantPactId.volatileEnvirons) ? 20 : 10;
      ship!.currentEvasion = max(0, ship!.currentEvasion - kelpPenalty);
      // Haze supplies a minimum penalty without stacking onto stronger ink.
      currentMonster!.isObscured = true;
      currentMonster!.obscuredAcMod = max(currentMonster!.obscuredAcMod, 10);
      final hazePenalty = currentMonster!.obscurityAccuracyPenalty;
      events.add(NarrationEvent(
        'Sargasso Hazard: Tangled Kelp fouls your ship\'s rudder (-$kelpPenalty% ship evasion). Phosphor Haze cloaks the beast in Obscurity (-$hazePenalty% shot accuracy, separate from monster dodge).',
      ));
    }

    final prevPhase = phase.displayName;
    phase = SessionPhase.battle;
    lastHelmOrderThisTurn = HelmOrder.holdLine;
    _disruptedBossCatastropheThisTurn = false;
    usedQuickConsumableThisTurn = false;
    quickConsumablesUsedThisTurn = 0;
    currentMonster!.currentIntent = selectNextMonsterIntent(
      currentMonster!,
      combatRange,
      rng,
      battleRound: battleRound,
    );

    events.add(PhaseChanged(
      previousPhase: prevPhase,
      newPhase: phase.displayName,
    ));
    if (isNemesisBattle) {
      events.add(NemesisSpawned(nemesis: profile.activeNemesis!));
    }
    events.add(BattleStarted(
      monsterName: currentMonster!.name,
      difficulty: seaChart.currentDifficulty,
      isBoss: seaChart.isRegionTitan,
      monsterHp: currentMonster!.maxHp,
      monsterAc: currentMonster!.armorClass,
      isApex: currentMonster!.isApex,
      apexTitle: currentMonster!.apexTitle,
    ));
    events.add(MonsterIntentTelegraphed(
      monsterName: currentMonster!.name,
      intent: currentMonster!.currentIntent!,
    ));
    return events;
  }

  /// Evaluates player hits against active monster intents for pinning and Boss Wind-Up disruption.
  List<GameEvent> _evaluatePlayerHitIntentInteractions({
    required int totalDamageDealt,
    ShipWeaponType? weaponType,
    ConsumableType? consumableType,
    StatusEffect? inflictedStatus,
  }) {
    if (currentMonster == null || !currentMonster!.isAlive) {
      return const <GameEvent>[];
    }
    final events = <GameEvent>[];

    final isPinningOrdnance = weaponType == ShipWeaponType.harpoonWinch ||
        weaponType == ShipWeaponType.heavyMortar ||
        consumableType == ConsumableType.blastPack;
    // Stun denies the response itself, without Pin's separate evasion penalty.
    // Both can still interrupt a titan's windup or imminent release.
    final interruptsCatastrophe = isPinningOrdnance ||
        inflictedStatus == StatusEffect.stun ||
        currentMonster!.hasStatus(StatusEffect.stun);

    if (isPinningOrdnance) {
      currentMonster!.isPinnedThisTurn = true;
      events.add(CombatEffectsChanged.capture(currentMonster!));
    }

    final intent = currentMonster!.currentIntent;
    if (intent != null &&
        (intent.isBossWindup || intent.isBossCatastropheStrike)) {
      currentMonster!.windupDamageTaken += totalDamageDealt;

      if (interruptsCatastrophe) {
        final reason = switch (weaponType) {
          ShipWeaponType.heavyMortar =>
            'Heavy Mortar concussive blast shattered the titan\'s stance!',
          ShipWeaponType.harpoonWinch =>
            'Harpoon Winch cables wrenched the titan off-balance!',
          _ => 'Concussive shockwave disrupted the catastrophic charge!',
        };

        events.add(MonsterIntentDisrupted(
          monsterName: currentMonster!.name,
          intentName: intent.name,
          reason: reason,
        ));

        switch (currentMonster!.species) {
          case MonsterSpecies.kraken:
            currentMonster!.setIntentCooldown(
              MonsterIntentId.bossKrakenWindup,
              3,
            );
          case MonsterSpecies.worldSerpent:
            currentMonster!.setIntentCooldown(
              MonsterIntentId.bossWorldSerpentWindup,
              3,
            );
          case MonsterSpecies.ancientLeviathan:
            currentMonster!.setIntentCooldown(
              MonsterIntentId.bossLeviathanWindup,
              3,
            );
          default:
            break;
        }
        currentMonster!.windupDamageTaken = 0;
        currentMonster!.currentIntent = null;
        _disruptedBossCatastropheThisTurn = true;
        events.add(CombatEffectsChanged.capture(currentMonster!));
      }
    }

    return events;
  }

  List<GameEvent> _handleFireWeaponVolley(ShipWeaponType weaponType) {
    if (phase != SessionPhase.battle || ship == null || currentMonster == null) {
      throw StateError('Cannot fire weapons outside of battle');
    }
    if (isImpatientRecovering) {
      throw StateError('Impatient: fittings must recover this turn.');
    }
    if (!ship!.equippedWeapons.any(
      (weapon) => weapon.isReady &&
          (weapon.weaponType == weaponType ||
              (weaponType == ShipWeaponType.cannon && !weapon.isSignature)),
    )) {
      throw StateError('No ready weapon of this type.');
    }
    if (!isWeaponTypeUsableAtRange(weaponType, combatRange)) {
      throw StateError(
          'Cannot fire ${weaponType.displayName} at ${combatRange.displayName}');
    }
    final events = <GameEvent>[];

    var accuracyBoon = gunneryAccuracyBoon + captainWeaponAccuracyModifier;
    gunneryAccuracyBoon = runicGuidanceBoon + shoreDrillBoon;

    double damageMultiplier = profile.monumentWeaponDamageMultiplier;
    if (isDaredevilActive) {
      damageMultiplier *= 1.30;
    }
    if (isNemesisBattle &&
        (activeBoon?.id == BloodlineTraitId.bloodOath ||
            activeQuirk?.id == BloodlineTraitId.bloodOath)) {
      damageMultiplier *= 1.30;
    }
    if (activeQuirk?.id == BloodlineTraitId.overzealousGunner) {
      damageMultiplier *= 1.20;
    }

    // Consume Gun-Deck Bracing utility buff (+15% Accuracy, +20% * markMult Damage)
    if (ship!.gunneryDrillBuffActive) {
      ship!.gunneryDrillBuffActive = false;
      final utilMult = ship!.hardpointMarkMultiplier(HardpointType.utility);
      final drillBonusPct = (20 * utilMult).round();
      accuracyBoon += 15;
      damageMultiplier *= (1.0 + 0.20 * utilMult);
      events.add(NarrationEvent(
        'Gun-Deck Bracing volley: +15% Accuracy and +$drillBonusPct% Damage!',
      ));
    }

    // Consume Alchemical Pitch Flask buff (+25% Fire Damage + Burn on hit)
    final hadPitchCoating = ship!.pitchCoatingActive;
    if (hadPitchCoating) {
      ship!.pitchCoatingActive = false;
      damageMultiplier *= 1.25;
    }
    events.add(CombatEffectsChanged.capture(ship!));

    // Ghostwake Rail-Culverin: ignores monster Obscurity
    final hasGhostwake =
        weaponType == ShipWeaponType.precisionCulverin &&
            profile.isEldritchRelicActive(EldritchRelicId.ghostwakeCulverin);
    final savedObscured = currentMonster!.isObscured;
    if (hasGhostwake) {
      currentMonster!.isObscured = false;
    }

    // Ram closes before its attack. Keep the launch range for damage/accuracy
    // calculations: the approved Medium charge bonus is momentum, not the
    // impact distance. Harpoon instead fires here and pulls after its attack.
    final launchRange = combatRange;
    if (weaponType == ShipWeaponType.prowRam && ship!.isAlive &&
        combatRange != CombatRange.short) {
      final previousRange = combatRange;
      combatRange = CombatRange.short;
      events.add(CombatRangeChanged(
        mover: CombatSide.ship,
        instigator: CombatSide.ship,
        previousRange: previousRange,
        newRange: combatRange,
        reason: 'Prow Ram kinetic charge surged into point-blank range!',
      ));
    }

    // Player volley
    final volleyEvents = executeShipWeaponVolley(
      ship!,
      weaponType,
      currentMonster!,
      rng,
      traits,
      accuracyBoon,
      damageMultiplier,
      launchRange,
    );
    if (hasGhostwake) {
      currentMonster!.isObscured = savedObscured;
    }
    // Ghostwake's temporary accuracy bypass is not an ink removal. Preserve
    // each rider's causal state while masking that implementation detail.
    events.addAll(volleyEvents.map((event) =>
      hasGhostwake && event is CombatEffectsChanged &&
          event.target == CombatSide.monster
        ? CombatEffectsChanged(target: event.target,
            state: event.state.withObscurity(savedObscured))
        : event));
    if (hasGhostwake) events.add(CombatEffectsChanged.capture(currentMonster!));
    _purgedFrenzyThisTurn =
        volleyEvents.whereType<SharkFrenzyDisrupted>().isNotEmpty;

    // If flagship was destroyed by point-blank mortar backfire
    if (!ship!.isAlive) {
      events.addAll(_resolvePlayerDeath());
      return events;
    }

    // Evaluate Post-Loop Eldritch Relic Weapon & Pitch Coating effects on hit
    final resolvedHits = volleyEvents
        .whereType<AttackHit>()
        .where((e) => e.targetName == currentMonster!.name && !e.isBlessingDamage)
        .toList();
    final carapaceHits = volleyEvents
        .whereType<CarapaceDamaged>()
        .where((e) => e.monsterName == currentMonster!.name)
        .toList();

    var totalDamageDealt =
        volleyEvents.whereType<AttackHit>()
            .where((e) => e.targetName == currentMonster!.name)
            .fold<int>(0, (sum, e) => sum + e.damage) +
            carapaceHits.fold<int>(0, (sum, e) => sum + e.damageDealt);

    if (resolvedHits.isNotEmpty || carapaceHits.isNotEmpty) {
      if (hadPitchCoating && currentMonster!.isAlive) {
        currentMonster!.addStatus(StatusEffect.burn);
        events.add(CombatEffectsChanged.capture(currentMonster!));
        events.add(NarrationEvent(
          'Alchemical Pitch ignites ${currentMonster!.name} in inextinguishable flames (Burn)!',
        ));
      }

      if (weaponType == ShipWeaponType.prowRam &&
          profile.isEldritchRelicActive(EldritchRelicId.siphonRam)) {
        final totalHullDmg =
            resolvedHits.fold<int>(0, (sum, e) => sum + e.damage);
        if (totalHullDmg > 0) {
          final leechHeal = max(1, (totalHullDmg * 0.30));
          final before = ship!.currentHp;
          ship!.heal(leechHeal);
          final restored = ship!.currentHp - before;
          events.add(CombatHealthChanged(target: CombatSide.ship,
            remainingHp: ship!.currentHp, amount: restored,
            source: 'Siphon Ram', isHealing: true));
          events.add(
            NarrationEvent(
              'Abyssal Siphon Ram drinks the beast\'s lifeblood, restoring $restored hull HP!',
            ),
          );
        }
      }

      if (hasGhostwake && currentMonster!.isAlive) {
        final shockDmg = amplifyMonsterDamage(
          ship!, currentMonster!, resolvedHits.length * 8);
        final before = currentMonster!.currentHp;
        currentMonster!.applyDamage(shockDmg);
        events.add(CombatHealthChanged(target: CombatSide.monster,
          remainingHp: currentMonster!.currentHp,
          amount: before - currentMonster!.currentHp,
          source: 'Ghostwake', isHealing: false));
        totalDamageDealt += shockDmg;
        events.add(NarrationEvent(
          'Ghostwake Rail-Culverin arcs abyssal lightning for +$shockDmg Shock damage!',
        ));
      }

      if (weaponType == ShipWeaponType.heavyMortar &&
          profile.isEldritchRelicActive(EldritchRelicId.brimstoneMortar) &&
          currentMonster!.isAlive) {
        currentMonster!.addStatus(StatusEffect.burn);
        events.add(CombatEffectsChanged.capture(currentMonster!));
        events.add(const NarrationEvent(
          'Caldera Brimstone Mortar coats the beast in searing hydrothermal sulfur (Burn)!',
        ));
      }

      if (weaponType == ShipWeaponType.harpoonWinch &&
          profile.isEldritchRelicActive(EldritchRelicId.sinewWinch) &&
          currentMonster!.isAlive) {
        currentMonster!.addStatus(StatusEffect.poison);
        events.add(CombatEffectsChanged.capture(currentMonster!));
        events.add(const NarrationEvent(
          'Kraken-Sinew Drag Winch constricts the quarry with venomous abyssal barbs (Poison)!',
        ));
      }

      events.addAll(_evaluatePlayerHitIntentInteractions(
        totalDamageDealt: totalDamageDealt,
        weaponType: weaponType,
      ));
    }

    // Harpoon Winch reels 1 band closer (and pulls monster into Drifting Tether-Trap if active!)
    if (weaponType == ShipWeaponType.harpoonWinch && combatRange != CombatRange.short) {
      final prev = combatRange;
      combatRange = combatRange.closer;
      events.add(CombatRangeChanged(
        mover: CombatSide.monster,
        instigator: CombatSide.ship,
        previousRange: prev,
        newRange: combatRange,
        reason: 'Harpoon Winch tightened cables, reeling the quarry closer!',
      ));
      events.addAll(triggerBoilingWake(ship!, currentMonster!));
      if (ship!.activeTetherTrapDistance != null && currentMonster!.isAlive) {
        ship!.activeTetherTrapDistance = ship!.activeTetherTrapDistance! - 1;
        if (ship!.activeTetherTrapDistance! <= 0) {
          events.addAll(detonateTetherTrap(
            ship!,
            currentMonster!,
            rng,
            traits,
            reason:
                'Harpoon Winch dragged ${currentMonster!.name} straight into the floating net',
          ));
        }
      }
    }

    // Check if monster defeated
    if (!currentMonster!.isAlive) {
      events.addAll(_resolveMonsterDefeat());
      return events;
    }

    // Monster response turn
    events.addAll(_finishPlayerAction(firedWeaponType: weaponType));
    return events;
  }

  List<GameEvent> _handleIssueHelmOrder(HelmOrder order) {
    if (phase != SessionPhase.battle || ship == null || currentMonster == null) {
      throw StateError('Cannot issue helm orders outside of battle');
    }
    if (ship!.isGrappled && order != HelmOrder.holdLine) {
      throw StateError(
          'Cannot maneuver while grappled by ${currentMonster!.name}; helm is locked to Hold Line!');
    }
    if (!combatRange.availableHelmOrders.contains(order)) {
      throw StateError(
          'Helm order ${order.displayName} is not permitted at ${combatRange.displayName}');
    }
    if ((usesLateHelm && _hasIssuedHelmThisTurn) ||
        isImpatientCombinationPending) {
      throw StateError('Only one helm commitment is permitted each turn.');
    }
    _hasIssuedHelmThisTurn = true;
    lastHelmOrderThisTurn = order;
    if (usesLateHelm) {
      _queuedHelmOrder = order;
      return [
        NarrationEvent(
          'Skirmisher commits to ${order.displayName} after the main action.',
        ),
      ];
    }
    final targetRange = combatRange.rangeAfterHelmOrder(order);
    if (combatRange == targetRange) {
      return <GameEvent>[
        NarrationEvent(
            'The helm holds steady at ${combatRange.displayName}.'),
      ];
    }
    final prev = combatRange;
    combatRange = targetRange;
    return <GameEvent>[
      CombatRangeChanged(
        mover: CombatSide.ship,
        instigator: CombatSide.ship,
        previousRange: prev,
        newRange: combatRange,
        reason:
            'Helm ordered to ${order.displayName} (${prev.displayName} -> ${targetRange.displayName}).',
      ),
    ];
  }

  List<GameEvent> _handleChangeCombatRange(CombatRange targetRange) {
    if (phase != SessionPhase.battle || ship == null || currentMonster == null) {
      throw StateError('Cannot change combat range outside of battle');
    }
    if (combatRange == targetRange) return const <GameEvent>[];
    if (ship!.isGrappled) {
      throw StateError(
          'Cannot maneuver while grappled by ${currentMonster!.name}; helm is locked to Hold Line!');
    }
    final isLegalStep = (combatRange == CombatRange.long && targetRange == CombatRange.medium) ||
        (combatRange == CombatRange.medium && (targetRange == CombatRange.short || targetRange == CombatRange.long)) ||
        (combatRange == CombatRange.short && targetRange == CombatRange.medium);
    if (!isLegalStep) {
      throw StateError(
          'Cannot shift directly from $combatRange to $targetRange in a single helm maneuver');
    }
    return _handleIssueHelmOrder(
      targetRange == combatRange.closer
          ? HelmOrder.advance
          : HelmOrder.fallBack,
    );
  }

  List<GameEvent> _handleUseHullPatchKit(String itemId, {required bool fromPendingLoot}) {
    if (!canUseHullPatchOutsideBattle || (fromPendingLoot &&
        phase != SessionPhase.loot && phase != SessionPhase.shipwreck)) {
      throw StateError('Hull Patch Kits cannot be used from this source here.');
    }
    final inventory = fromPendingLoot ? pendingLoot : ship!.cargo;
    final index = inventory.indexWhere((item) => item.id == itemId);
    if (index < 0) throw StateError('This kit is no longer available.');
    final item = inventory[index];
    if (item is! Consumable || item.type != ConsumableType.hullPatchKit || item.isDepleted) {
      throw StateError('Only a usable Hull Patch Kit has this outside-battle role.');
    }
    if (hullPatchHealingHp <= 0) {
      return const [NarrationEvent('Hull already full; the kit remains unspent.')];
    }
    final before = ship!.currentHp;
    ship!.heal(max(1, ship!.maxHp * 0.30));
    item.usesLeft = 0;
    inventory.removeAt(index);
    final events = <GameEvent>[HullPatchApplied(itemId: item.id,
      fromPendingLoot: fromPendingLoot, restoredHp: ship!.currentHp - before, newHp: ship!.currentHp)];
    if (fromPendingLoot && pendingLoot.isEmpty && phase == SessionPhase.loot) {
      events.addAll(_finishLoot());
    }
    return events;
  }

  List<GameEvent> _handleUseConsumable(int cargoIndex) {
    if (phase != SessionPhase.battle || ship == null || currentMonster == null) {
      throw StateError('Cannot use consumable outside of battle');
    }
    if (cargoIndex < 0 || cargoIndex >= ship!.cargo.length) {
      throw RangeError('Invalid cargo index: $cargoIndex');
    }
    final item = ship!.cargo[cargoIndex];
    if (item is! Consumable) {
      throw ArgumentError('Item at index $cargoIndex is not a consumable');
    }
    if (item.isDepleted) {
      throw StateError('This consumable has already been spent');
    }
    final maxQuickItems = activeBoon?.id == BloodlineTraitId.drillmaster
        ? 2
        : 1;
    if (quickConsumablesUsedThisTurn >= maxQuickItems) {
      throw StateError(
          'Already used the maximum Quick Action consumables allowed this round');
    }

    quickConsumablesUsedThisTurn++;
    usedQuickConsumableThisTurn = quickConsumablesUsedThisTurn >= maxQuickItems;

    final events = <GameEvent>[];
    item.usesLeft--;

    switch (item.type) {
      case ConsumableType.hullPatchKit:
        final healAmt = max(1, (ship!.maxHp * 0.30));
        final before = ship!.currentHp;
        ship!.heal(healAmt);
        final restored = ship!.currentHp - before;
        events.add(CombatHealthChanged(target: CombatSide.ship,
          remainingHp: ship!.currentHp, amount: restored,
          source: 'Hull Patch', isHealing: true));
        events.add(
          NarrationEvent(
            'Quick Action (0T): ${item.name} braced hull breaches, restoring $restored HP (${ship!.currentHp}/${ship!.maxHp})!',
          ),
        );
      case ConsumableType.krakenInkBomb:
        ship!.currentEvasion = min(95, ship!.currentEvasion + 25);
        events.add(CombatEffectsChanged.capture(ship!));
        events.add(NarrationEvent(
          'Quick Action (0T): ${item.name} billows an abyssal smoke screen (+25% Evasion)!',
        ));
      case ConsumableType.alchemicalPitch:
        ship!.pitchCoatingActive = true;
        events.add(CombatEffectsChanged.capture(ship!));
        events.add(NarrationEvent(
          'Quick Action (0T): ${item.name} coats the deck guns in incendiary pitch (+25% Fire damage & Burn on next volley)!',
        ));
      case ConsumableType.unstableTincture:
      case ConsumableType.blastPack:
      case ConsumableType.chakram:
        final result = resolveConsumableEffect(item, rng);
        if (result.didHit) {
          final damage =
              amplifyMonsterDamage(ship!, currentMonster!, result.damage);
          if (result.damage > 0) {
            if (item.type == ConsumableType.blastPack &&
                currentMonster!.carapacePlating > 0) {
              final blastCarapace = damage * 2;
              if (currentMonster!.carapacePlating > blastCarapace) {
                currentMonster!.carapacePlating -= blastCarapace;
                events.add(CarapaceDamaged(
                  monsterName: currentMonster!.name,
                  damageDealt: blastCarapace,
                  remainingCarapace: currentMonster!.carapacePlating,
                  wasShattered: false,
                ));
              } else {
                final broken = currentMonster!.carapacePlating;
                final overflow =
                    max(0, damage - (broken ~/ 2));
                currentMonster!.carapacePlating = 0;
                events.add(CarapaceDamaged(
                  monsterName: currentMonster!.name,
                  damageDealt: broken,
                  remainingCarapace: 0,
                  wasShattered: true,
                ));
                if (overflow > 0) {
                  currentMonster!.applyDamage(overflow);
                  events.add(AttackHit(
                    target: CombatSide.monster,
                    source: item.name,
                    targetName: currentMonster!.name,
                    damage: overflow,
                    damageType: result.damageType.displayName,
                    remainingHp: currentMonster!.currentHp,
                  ));
                }
              }
            } else {
              currentMonster!.applyDamage(damage);
              events.add(AttackHit(
                target: CombatSide.monster,
                source: item.name,
                targetName: currentMonster!.name,
                damage: damage,
                damageType: result.damageType.displayName,
                remainingHp: currentMonster!.currentHp,
              ));
            }
          }
          if (result.statusEffect != null) {
            currentMonster!.addStatus(result.statusEffect!);
            events.add(CombatEffectsChanged.capture(currentMonster!));
            events.add(NarrationEvent(
              result.description.isNotEmpty
                  ? result.description
                  : '${item.name} inflicts ${result.statusEffect!.displayName}!',
            ));
          }
          events.addAll(_evaluatePlayerHitIntentInteractions(
            totalDamageDealt: damage,
            consumableType: item.type,
            inflictedStatus: result.statusEffect,
          ));
        } else {
          events.add(AttackMissed(targetName: currentMonster!.name, target: CombatSide.monster));
        }
    }

    if (item.isDepleted) {
      ship!.cargo.removeAt(cargoIndex);
    }

    // Check if monster defeated
    if (!currentMonster!.isAlive) {
      events.addAll(_resolveMonsterDefeat());
      return events;
    }

    if (activeBoon?.id == BloodlineTraitId.drillmaster) {
      events.add(const NarrationEvent(
        "Drillmaster: Quick hands primed the munition without forfeiting the ship's combat initiative!",
      ));
    }

    // Tactical Belt consumables are 0-Turn-Cost Quick Actions!
    return events;
  }

  List<GameEvent> _handleShipSpecialAction({bool borrowNextAction = false}) {
    if (phase != SessionPhase.battle || ship == null) {
      throw StateError('Cannot use special action outside of battle');
    }
    if (isImpatientCombinationPending || isImpatientRecovering) {
      throw StateError(
        'Impatient: utility is unavailable until recovery ends.',
      );
    }
    if (borrowNextAction && !canStartImpatientCombination) {
      throw StateError('Cannot start an Impatient combination.');
    }
    if (!ship!.isAlive) {
      return _finishPlayerAction(usedUtility: true);
    }
    if (ship!.utilityCooldown > 0) {
      throw StateError(
          'Utility fitting is on cooldown (${ship!.utilityCooldown}T remaining)');
    }
    final events = <GameEvent>[];

    final bpId = BlueprintId.values.firstWhere(
      (b) => b.name == ship!.blueprintId,
      orElse: () => ship!.shipClass.blueprintId,
    );
    final utility = bpId.utilityHardpoint;
    final markMult = ship!.hardpointMarkMultiplier(HardpointType.utility);
    ship!.utilityCooldown = 2;

    switch (utility) {
      case UtilityHardpointId.gunneryDrill:
        ship!.isBracedByDrill = true;
        ship!.gunneryDrillBuffActive = true;
        final dmgBonusPct = (20 * markMult).round();
        events.add(NarrationEvent(
          'Gun-Deck Bracing: ${ship!.name}\'s crew sets the hull and gun-deck braces to take the impact (-20% incoming damage this round) and steady the guns (+15% Accuracy & +$dmgBonusPct% Damage on next volley)!',
        ));
      case UtilityHardpointId.fortifyPlates:
        final msg = const FortifyTrait().executeSpecialAction(
          ship!,
          currentMonster!,
          rng,
        );
        if (msg.isNotEmpty) {
          events.add(NarrationEvent(msg));
        }
      case UtilityHardpointId.evasiveRigging:
        final msg = const EvasionTrait().executeSpecialAction(
          ship!,
          currentMonster!,
          rng,
        );
        if (msg.isNotEmpty) {
          events.add(NarrationEvent(msg));
        }
        if (combatRange != CombatRange.long && !ship!.isGrappled) {
          final prev = combatRange;
          combatRange = combatRange.farther;
          events.add(CombatRangeChanged(
            mover: CombatSide.ship,
            instigator: CombatSide.ship,
            previousRange: prev,
            newRange: combatRange,
            reason:
                'Evasive Rigging caught the wind, falling back to open water!',
          ));
        }
      case UtilityHardpointId.driftingTetherTrap:
        final trapDamage = ((16 + 5 * (ship!.level - 1)) * markMult).round();
        ship!.activeTetherTrapDamage = trapDamage;
        switch (combatRange) {
          case CombatRange.short:
            ship!.activeTetherTrapDistance = 0;
            events.addAll(detonateTetherTrap(
              ship!,
              currentMonster!,
              rng,
              traits,
              reason:
                  '${ship!.name} launched a Drifting Tether-Trap at point-blank range',
            ));
            if (!currentMonster!.isAlive) {
              events.addAll(_resolveMonsterDefeat());
              return events;
            }
          case CombatRange.medium:
            ship!.activeTetherTrapDistance = 1;
            events.add(NarrationEvent(
              '${ship!.name} launches a Drifting Tether-Trap into Short Range (Distance to ${currentMonster!.name}: 1 band)!',
            ));
          case CombatRange.long:
            ship!.activeTetherTrapDistance = 2;
            events.add(NarrationEvent(
              '${ship!.name} launches a Drifting Tether-Trap into Medium Range (Distance to ${currentMonster!.name}: 2 bands)!',
            ));
        }
      case UtilityHardpointId.spotterFlare:
        currentMonster!.spotterFlareTurns = 2;
        currentMonster!.spotterFlareAccuracyBonus = (15 * markMult).round();
        currentMonster!.spotterFlareBlastBonus = 0.25 * markMult;
        currentMonster!.isObscured = false;
        currentMonster!.evasion = 0;
        events.add(NarrationEvent(
          '${ship!.name} fires a Phosphor Spotter Flare! ${currentMonster!.name} is illuminated for 2 turns (Obscurity & Evasion suppressed, +${currentMonster!.spotterFlareAccuracyBonus}% Accuracy, +${(currentMonster!.spotterFlareBlastBonus * 100).round()}% Blast damage taken)!',
        ));
    }

    events.add(CombatEffectsChanged.capture(ship!));
    events.add(CombatEffectsChanged.capture(currentMonster!));
    final blessingEvents = activateUtilityBlessing(ship!, currentMonster!);
    events.addAll(blessingEvents);
    _purgedFrenzyThisTurn =
        blessingEvents.whereType<SharkFrenzyDisrupted>().isNotEmpty;
    if (!currentMonster!.isAlive) {
      events.addAll(_resolveMonsterDefeat());
      return events;
    }
    // Monster response turn
    if (borrowNextAction) {
      isImpatientCombinationPending = true;
      events.add(
        const NarrationEvent(
          'Impatient: fire a ready weapon now; fittings recover next turn.',
        ),
      );
    } else {
      events.addAll(_finishPlayerAction(usedUtility: true));
    }
    return events;
  }

  List<GameEvent> _handleBraceForImpact() {
    if (phase != SessionPhase.battle || ship == null) {
      throw StateError('Cannot wait and reload outside of battle');
    }
    if (isImpatientCombinationPending) {
      throw StateError('Impatient: finish the combination with a weapon.');
    }
    final events = <GameEvent>[];

    // Emergency/recovery pass only; waiting grants no defensive boost.
    events.add(NarrationEvent(
      '${ship!.name}\'s crew waits while the fittings recover and ordnance reloads.',
    ));

    // Monster response turn
    events.addAll(_finishPlayerAction());
    return events;
  }

  List<GameEvent> _finishPlayerAction({
    ShipWeaponType? firedWeaponType,
    bool usedUtility = false,
  }) {
    final events = <GameEvent>[];
    if (_queuedHelmOrder case final order?) {
      final previous = combatRange;
      combatRange = combatRange.rangeAfterHelmOrder(order);
      if (combatRange != previous) {
        events.add(
          CombatRangeChanged(
            mover: CombatSide.ship,
            instigator: CombatSide.ship,
            previousRange: previous,
            newRange: combatRange,
            reason: 'Skirmisher: ${order.displayName} after the main action.',
          ),
        );
      }
    }
    _queuedHelmOrder = null;
    final combination = isImpatientCombinationPending;
    isImpatientCombinationPending = false;
    isImpatientRecovering = combination;
    events.addAll(
      _resolveMonsterTurn(
        firedWeaponType: firedWeaponType,
        usedUtility: usedUtility || combination,
      ),
    );
    return events;
  }

  List<GameEvent> _resolveMonsterTurn({
    ShipWeaponType? firedWeaponType,
    bool usedUtility = false,
  }) {
    final events = <GameEvent>[];
    final electroJoltWasActiveAtStart = currentMonster!.isElectroJolted;

    // Expire single-round ship debuffs after the player's turn has concluded
    ship!.isGrappled = false;
    ship!.tempAccuracyPenalty = 0;
    usedQuickConsumableThisTurn = false;
    quickConsumablesUsedThisTurn = 0;
    events.add(CombatEffectsChanged.capture(ship!));

    // Status effect tick on monster
    final monsterStatus = updateStatusEffects(
      currentMonster!,
      seaChart.currentDifficulty,
      rng,
      config,
      ship!,
      seaChart.currentRegionIndex,
    );
    events.addAll(monsterStatus.events);
    if (!currentMonster!.isAlive) {
      events.addAll(_resolveMonsterDefeat());
      return events;
    }

    // Feeding Frenzy Pact: Shark triggers frenzy at <= 60% HP instead of 40%
    if (profile.isPactActive(CovenantPactId.feedingFrenzy) &&
        !_purgedFrenzyThisTurn &&
        currentMonster!.species == MonsterSpecies.shark &&
        currentMonster!.frenzyStacks == 0 &&
        currentMonster!.currentHp <= (currentMonster!.maxHp * 0.60).round()) {
      currentMonster!.frenzyStacks = 1;
      events.add(SharkFrenzyRoared(
        monsterName: currentMonster!.name,
        stacks: 1,
      ));
    }

    // Monster executes its telegraphed intent if it can act and wasn't disrupted
    if (_disruptedBossCatastropheThisTurn) {
      events.add(MonsterHesitated(currentMonster!.name));
      currentMonster!.tickIntentCooldowns();
      currentMonster!.isPinnedThisTurn = false;
    } else if (monsterStatus.canAct) {
      if (currentMonster!.currentIntent != null) {
        final (newRange, intentEvents) = executeMonsterIntent(
          currentMonster!,
          ship!,
          rng,
          combatRange,
          config,
          traits,
          lastHelmOrderThisTurn,
        );
        combatRange = newRange;
        events.addAll(intentEvents);
      } else {
        events.addAll(takeMonsterTurn(
          currentMonster!,
          ship!,
          rng,
          config,
          traits,
          combatRange,
        ));
      }
    } else {
      currentMonster!.tickIntentCooldowns();
      currentMonster!.isPinnedThisTurn = false;
      currentMonster!.currentIntent = null;
    }

    events.addAll(finishOceanPowerTurn(ship!, currentMonster!,
        electroJoltWasActiveAtStart: electroJoltWasActiveAtStart));
    _purgedFrenzyThisTurn = false;
    _disruptedBossCatastropheThisTurn = false;
    lastHelmOrderThisTurn = HelmOrder.holdLine;
    _hasIssuedHelmThisTurn = false;
    ship!.isAnchoredThisTurn = false;
    ship!.isBracedByDrill = false;
    events.add(CombatEffectsChanged.capture(ship!));
    events.add(CombatEffectsChanged.capture(currentMonster!));

    // A fatal strike remains fatal even when reactive powers also kill its source.
    if (!ship!.isAlive) {
      events.addAll(_resolvePlayerDeath());
      return events;
    }

    // Check if monster died from reactive powers or a trap during its movement.
    if (!currentMonster!.isAlive) {
      events.addAll(_resolveMonsterDefeat());
      return events;
    }

    // End of round: decrement cooldowns on weapons/utility NOT used this turn
    for (final weapon in ship!.equippedWeapons) {
      if (weapon.weaponType != firedWeaponType) {
        weapon.decrementChargeCountdown();
      }
    }
    if (!usedUtility && ship!.utilityCooldown > 0) {
      ship!.utilityCooldown--;
    }
    currentMonster!.tickSpotterFlare();
    events.add(CombatEffectsChanged.capture(currentMonster!));

    // Region 3 Hazard: Thermal Caldera Scald every 3 combat rounds (or every 2 rounds for 15 dmg under Volatile Environs)
    final volatileActive =
        profile.isPactActive(CovenantPactId.volatileEnvirons);
    final scaldInterval = volatileActive ? 2 : 3;
    if (seaChart.currentRegionIndex == 2 && battleRound % scaldInterval == 0) {
      final scaldDamage = volatileActive ? 15 : 10;
      ship!.applyDamage(scaldDamage);
      events.add(ThermalScaldOccurred(
        shipName: ship!.name,
        damage: scaldDamage,
        remainingHp: ship!.currentHp,
      ));
      if (!ship!.isAlive) {
        events.addAll(_resolvePlayerDeath());
        return events;
      }
    }

    battleRound++;

    // Start of new round: Ocean current drifts Corsair Tether-Trap 1 space closer to the monster
    if (ship!.activeTetherTrapDistance != null && currentMonster!.isAlive) {
      ship!.activeTetherTrapDistance = ship!.activeTetherTrapDistance! - 1;
      if (ship!.activeTetherTrapDistance! <= 0) {
        events.addAll(detonateTetherTrap(
          ship!,
          currentMonster!,
          rng,
          traits,
          reason:
              'Ocean currents drifted the Tether-Trap into ${currentMonster!.name}',
        ));
        if (!currentMonster!.isAlive) {
          events.addAll(_resolveMonsterDefeat());
          return events;
        }
      } else {
        events.add(NarrationEvent(
          'Ocean currents drift the Tether-Trap closer to ${currentMonster!.name} (Distance: ${ship!.activeTetherTrapDistance} band)!',
        ));
      }
    }

    // Status effect tick on ship
    final shipStatus = updateStatusEffects(
      ship!,
      seaChart.currentDifficulty,
      rng,
      config,
    );
    events.addAll(shipStatus.events);
    if (!ship!.isAlive) {
      events.addAll(_resolvePlayerDeath());
      return events;
    }

    // Select and telegraph the monster's intent for the next combat round
    if (currentMonster != null &&
        currentMonster!.isAlive &&
        currentMonster!.currentIntent == null) {
      final nextIntent = selectNextMonsterIntent(
        currentMonster!,
        combatRange,
        rng,
        battleRound: battleRound,
      );
      currentMonster!.currentIntent = nextIntent;
      events.add(MonsterIntentTelegraphed(
        monsterName: currentMonster!.name,
        intent: nextIntent,
      ));
    }

    return events;
  }

  List<GameEvent> _resolveMonsterDefeat() {
    _resetCombatActionStages();
    final events = <GameEvent>[];
    runicGuidanceBoon = 0;
    gunneryAccuracyBoon = 0;
    shoreDrillBoon = 0;
    monstersDefeatedThisLife++;
    hasDefeatedCurrentEncounter = true;
    if (currentWreck?.stage == WreckStage.fighting) {
      currentWreck!..threatCleared = true..stage = WreckStage.recovery;
    }
    highestDifficultyThisLife = max(
      highestDifficultyThisLife,
      seaChart.currentDifficulty,
    );

    final isApex = currentMonster?.isApex ?? false;
    seaChart.recordCurrentOutcome(combatWon: true, species: currentMonster?.species, apex: isApex);
    final rawGold = calculateVoyageVictoryGold(
      seaChart.currentDifficulty,
      rng,
      isApex: isApex,
      isTitan: !isNemesisBattle && seaChart.isRegionTitan,
      tuning: seaChart.tuning.economy,
    );
    final goldSalvaged =
        (rawGold * profile.monumentBountyGoldMultiplier).round();
    if (ship != null) {
      ship!.gold += goldSalvaged;
    }
    lastGoldSalvaged = goldSalvaged;

    pendingLoot = generateTacticalVictoryLoot(
      seaChart.currentDifficulty,
      rng,
      1,
      2,
      isApex,
    );
    ship!.decrementChargeTimeOnWeapons();
    ship!.resetCombatBoosts();
    combatRange = CombatRange.medium;

    final prevPhase = phase.displayName;
    phase = SessionPhase.loot;

    events.add(PhaseChanged(
      previousPhase: prevPhase,
      newPhase: phase.displayName,
    ));
    events.add(LootDropped(
      items: List<Item>.from(pendingLoot),
      goldSalvaged: goldSalvaged,
    ));

    // Meta-currency & Nemesis reward resolution
    if (isNemesisBattle && profile.activeNemesis != null) {
      final nem = profile.activeNemesis!;
      if (ship != null) {
        ship!.gold += nem.bountyGold;
      }
      profile.metaInventory.add(
        seaGlass: nem.bountySeaGlass,
        monsterBone: nem.bountyMonsterBone,
        abyssalBarnacles: nem.bountyBarnacles,
      );
      events.add(NemesisSlain(nemesis: nem));
      events.add(MetaCurrenciesAwarded(
        seaGlass: nem.bountySeaGlass,
        monsterBone: nem.bountyMonsterBone,
        abyssalBarnacles: nem.bountyBarnacles,
        reason: 'Nemesis Slain: ${nem.moniker}',
      ));
      profile.activeNemesis = null;
      isNemesisBattle = false;
    } else {
      final boneDrop = rng.nextIntRange(1, 2) + (isApex ? 1 : 0);
      final barnacleDrop =
          (isApex || seaChart.currentRegionIndex >= 1) && rng.nextInt(100) < 35
              ? 1
              : 0;
      final krakenDrop =
          currentMonster?.species == MonsterSpecies.kraken ? 1 : 0;
      final serpentDrop =
          currentMonster?.species == MonsterSpecies.worldSerpent ? 1 : 0;
      final leviathanDrop =
          currentMonster?.species == MonsterSpecies.ancientLeviathan ? 1 : 0;

      // Primordial Cinders drop strictly from Region Titans defeated under active Pact Burden
      final burden = profile.totalPactBurden;
      final cinderDrop = burden > 0
          ? switch (currentMonster?.species) {
              MonsterSpecies.kraken => 1 + (burden ~/ 2),
              MonsterSpecies.worldSerpent => 2 + (burden ~/ 2),
              MonsterSpecies.ancientLeviathan => 3 + burden,
              _ => 0,
            }
          : 0;

      profile.metaInventory.add(
        monsterBone: boneDrop,
        abyssalBarnacles: barnacleDrop,
        krakenBeak: krakenDrop,
        serpentScale: serpentDrop,
        leviathanCore: leviathanDrop,
        primordialCinders: cinderDrop,
      );

      events.add(MetaCurrenciesAwarded(
        monsterBone: boneDrop,
        abyssalBarnacles: barnacleDrop,
        krakenBeak: krakenDrop,
        serpentScale: serpentDrop,
        leviathanCore: leviathanDrop,
        primordialCinders: cinderDrop,
        reason: 'Harvested from ${currentMonster?.name ?? 'sea beast'}',
      ));
    }

    return events;
  }

  List<GameEvent> _resolvePlayerDeath() {
    if (currentWreck?.stage == WreckStage.fighting) currentWreck!.stage = WreckStage.lost;
    _resetCombatActionStages();
    final events = <GameEvent>[];
    ship?.resetCombatBoosts();
    runicGuidanceBoon = 0;
    gunneryAccuracyBoon = 0;
    shoreDrillBoon = 0;
    lineage.recordDeath(CaptainRecord(
      captainName: captainName,
      shipName: ship!.name,
      shipClass: ship!.shipClass,
      monstersDefeated: monstersDefeatedThisLife,
      highestDifficultyReached: highestDifficultyThisLife,
      causeOfDeath: currentMonster?.name ?? 'The Undying Sea',
    ));

    // Titans remain unique bosses, not the next captain's vengeance target.
    // Clear a predecessor's older target too: this succession follows the
    // current death and must not offer Vendetta for an unrelated earlier killer.
    if (currentMonster?.species.isRegionTitan == true) {
      profile.activeNemesis = null;
    }
    if (currentMonster != null && !currentMonster!.species.isRegionTitan) {
      final nemesis = NemesisRecord.createFromDefeat(
        killer: currentMonster!,
        captainName: captainName.isNotEmpty ? captainName : 'Unknown Captain',
        regionIndex: seaChart.currentRegionIndex,
        rng: rng,
      );
      profile.activeNemesis = nemesis;
      events.add(NemesisSpawned(nemesis: nemesis));
    }

    // Generate 3 Heir Candidates for succession
    pendingHeirCandidates = generateHeirCandidates(
      rng: rng,
      previousCaptainName: captainName,
      nemesisSpecies: profile.activeNemesis?.species,
      count: 3,
    );

    final prevPhase = phase.displayName;
    phase = SessionPhase.death;

    events.add(PhaseChanged(
      previousPhase: prevPhase,
      newPhase: phase.displayName,
    ));
    events.add(CaptainLost(
      captainName: captainName,
      monstersDefeated: monstersDefeatedThisLife,
      highestDifficulty: highestDifficultyThisLife,
    ));
    return events;
  }

  List<GameEvent> _handleTakeLootItem(int lootIndex) {
    if ((phase != SessionPhase.loot && phase != SessionPhase.shipwreck) || ship == null) {
      throw StateError('Cannot take loot outside of loot phase');
    }
    if (lootIndex < 0 || lootIndex >= pendingLoot.length) {
      throw RangeError('Invalid loot index: $lootIndex');
    }
    final item = pendingLoot[lootIndex];
    if (ship!.addCargo(item)) {
      pendingLoot.removeAt(lootIndex);
      final events = <GameEvent>[ItemAcquired(item: item)];
      if (pendingLoot.isEmpty && phase == SessionPhase.loot) {
        events.addAll(_finishLoot());
      }
      return events;
    }
    return <GameEvent>[
      NarrationEvent('Cargo Hold is full! Cannot take ${item.name}'),
    ];
  }

  List<GameEvent> _handleTakeAllLoot() {
    if ((phase != SessionPhase.loot && phase != SessionPhase.shipwreck) || ship == null) {
      throw StateError('Cannot take loot outside of loot phase');
    }
    final events = <GameEvent>[];
    final itemsToKeep = <Item>[];

    for (final item in pendingLoot) {
      if (ship!.addCargo(item)) {
        events.add(ItemAcquired(item: item));
      } else {
        itemsToKeep.add(item);
      }
    }
    pendingLoot = itemsToKeep;
    if (pendingLoot.isEmpty && phase == SessionPhase.loot) {
      events.addAll(_finishLoot());
    }
    return events;
  }

  List<GameEvent> _handleLeaveRemainingLoot() {
    if (phase != SessionPhase.loot && phase != SessionPhase.shipwreck) {
      throw StateError('Cannot leave loot outside of a reward encounter');
    }
    if (phase == SessionPhase.shipwreck) {
      if (pendingLoot.isEmpty) return const [NarrationEvent('No unclaimed wreck supplies remain.')];
      pendingLoot.clear();
      wreckSalvageReceipt.add('Unclaimed supplies left aboard the wreck.');
      return const <GameEvent>[NarrationEvent('Unclaimed wreck supplies left behind.')];
    }
    pendingLoot.clear();
    return _finishLoot();
  }

  List<GameEvent> _finishLoot() {
    final previous = phase.displayName;
    phase = currentWreck?.stage == WreckStage.recovery
        ? SessionPhase.shipwreck : SessionPhase.restArea;
    return [PhaseChanged(previousPhase: previous, newPhase: phase.displayName)];
  }

  List<GameEvent> _handleDropCargo(int cargoIndex) {
    if (ship == null || cargoIndex < 0 || cargoIndex >= ship!.cargo.length) {
      throw RangeError('Invalid cargo index: $cargoIndex');
    }
    final dropped = ship!.cargo.removeAt(cargoIndex);
    return <GameEvent>[
      NarrationEvent('${dropped.name} jettisoned into the sea.'),
    ];
  }

  List<GameEvent> _handleEquipCargoWeapon(int cargoIndex) {
    if (ship == null || cargoIndex < 0 || cargoIndex >= ship!.cargo.length) {
      throw RangeError('Invalid cargo index: $cargoIndex');
    }
    final item = ship!.cargo[cargoIndex];
    if (item is! ShipWeapon) {
      throw ArgumentError('Item at index $cargoIndex is not a ship weapon');
    }
    if (ship!.equipWeapon(item)) {
      return <GameEvent>[
        NarrationEvent('${item.name} equipped.'),
      ];
    }
    return <GameEvent>[
      NarrationEvent('Cannot equip ${item.name}: no open deck fittings available.'),
    ];
  }

  List<GameEvent> _handleUnequipShipWeapon(int equippedIndex) {
    if (ship == null ||
        equippedIndex < 0 ||
        equippedIndex >= ship!.equippedWeapons.length) {
      throw RangeError('Invalid equipped index: $equippedIndex');
    }
    final weapon = ship!.equippedWeapons[equippedIndex];
    if (ship!.unequipWeapon(weapon)) {
      return <GameEvent>[
        NarrationEvent('${weapon.name} unequipped to cargo hold.'),
      ];
    }
    return <GameEvent>[
      NarrationEvent('No cargo hold space available to unequip ${weapon.name}.'),
    ];
  }

  List<GameEvent> _handleReturnToPort() {
    throw StateError('The home port is only available between voyages after succession');
  }

  List<GameEvent> _handleVisitMerchant() {
    if (phase != SessionPhase.port && phase != SessionPhase.stronghold) {
      throw StateError('Cannot visit merchant from $phase');
    }
    final prevPhase = phase.displayName;
    merchantReturnPhase = phase;
    phase = SessionPhase.merchant;
    return <GameEvent>[
      PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ),
    ];
  }

  List<GameEvent> _handleLeaveMerchant() {
    if (phase != SessionPhase.merchant) {
      throw StateError('Cannot leave merchant from $phase');
    }
    if (merchantReturnPhase == SessionPhase.helm) return _handleTakeHelm();
    final prevPhase = phase.displayName;
    phase = merchantReturnPhase;
    return <GameEvent>[
      PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ),
    ];
  }

  List<GameEvent> _handleBuyMerchantItem(int stockIndex) {
    if ((phase != SessionPhase.merchant && phase != SessionPhase.smuggler) || ship == null) {
      throw StateError('Cannot buy items outside of merchant shop or smuggler ketch');
    }
    final stock = phase == SessionPhase.smuggler ? smugglerStock : merchantStock;
    if (stockIndex < 0 || stockIndex >= stock.length) {
      throw RangeError('Invalid stock index: $stockIndex');
    }
    final item = stock[stockIndex];
    final cost = phase == SessionPhase.smuggler ? item.value : getMerchantAskingPrice(stockIndex);
    if (buyItem(ship!, item, price: cost)) {
      stock.removeAt(stockIndex);
      if (phase == SessionPhase.merchant && onSaleMerchantIndex != null) {
        if (stockIndex == onSaleMerchantIndex) {
          onSaleMerchantIndex = null;
        } else if (stockIndex < onSaleMerchantIndex!) {
          onSaleMerchantIndex = onSaleMerchantIndex! - 1;
        }
      }
      return <GameEvent>[ItemAcquired(item: item)];
    }
    return <GameEvent>[
      NarrationEvent('Cannot purchase ${item.name}: insufficient gold or cargo.'),
    ];
  }

  List<GameEvent> _handleBuyMerchantMaterial(String shipmentId, TradeMaterial material, int quantity) {
    final stock = currentMaterialShipment;
    if (ship == null || !ship!.isAlive || stock == null || stock.id != shipmentId) {
      throw StateError('This material shipment is no longer available.');
    }
    if (quantity <= 0) throw ArgumentError.value(quantity, 'quantity');
    final cost = quantity * materialUnitPrice(material);
    if (stock.quantity(material) < quantity || ship!.gold < cost) {
      return [const NarrationEvent('Cannot purchase: insufficient stock or gold.')];
    }
    ship!.gold -= cost;
    stock.remove(material, quantity);
    profile.metaInventory.add(
      seaGlass: material == TradeMaterial.seaGlass ? quantity : 0,
      depthWroughtIron: material == TradeMaterial.depthWroughtIron ? quantity : 0,
    );
    return [MaterialPurchased(material: material, quantity: quantity, goldCost: cost)];
  }

  List<GameEvent> _handleSellCargoItem(int cargoIndex) {
    if ((phase != SessionPhase.merchant && phase != SessionPhase.smuggler) || ship == null) {
      throw StateError('Cannot sell items outside of merchant shop or smuggler ketch');
    }
    if (cargoIndex < 0 || cargoIndex >= ship!.cargo.length) {
      throw RangeError('Invalid cargo index: $cargoIndex');
    }
    final item = ship!.cargo[cargoIndex];
    final goldEarned = item.value;
    if (sellItem(ship!, item)) {
      return <GameEvent>[ItemSold(item: item, goldEarned: goldEarned)];
    }
    return const <GameEvent>[];
  }

  List<GameEvent> _handleSellAllTreasure() {
    if (ship == null) throw StateError('No ship available');
    final (totalGold, itemsSold) = sellAllTreasure(ship!);
    return <GameEvent>[
      AllTreasureSold(totalGold: totalGold, itemsSold: itemsSold),
    ];
  }

  List<GameEvent> _handleRepairShip(double percentage) {
    if (ship == null) throw StateError('No ship available');

    final hp = repairHpFor(percentage);
    final cost = repairCostFor(percentage);
    if (hp <= 0) {
      if (phase == SessionPhase.restArea || phase == SessionPhase.helm) {
        return const [NarrationEvent(
          'The open sea is too turbulent for routine repairs. Seek a Respite Island or voyage stronghold.',
        )];
      }
      if (hasPaidRepairService && ship!.currentHp < ship!.maxHp) {
        return const [NarrationEvent('No effective paid repair work remains for this purchase.')];
      }
      return const [NarrationEvent('Hull needs no repairs here.')];
    }
    if (ship!.gold < cost) {
      return [
        NarrationEvent('Insufficient gold for repairs ($cost gold needed).'),
      ];
    }
    if (hasPaidRepairService) {
      final quote = paidRepairQuote(percentage)!;
      return _purchasePaidRepair(quote);
    }
    final nominal = _repairNominal(percentage);
    ship!.gold -= cost;
    ship!.heal(nominal);
    return [
      ShipRepaired(repairedHp: hp, goldCost: cost, newHp: ship!.currentHp, normalWorkUsed: nominal),
    ];
  }

  List<GameEvent> _handleAffordablePaidRepairs() {
    final quote = affordablePaidRepairQuote;
    if (quote == null) throw StateError('No paid repair service is available here.');
    return _purchasePaidRepair(quote);
  }

  List<GameEvent> _purchasePaidRepair(PaidRepairQuote quote) {
    if (!applyPaidRepair(ship!, paidRepairWork, quote)) {
      return const [NarrationEvent('No affordable paid repair work could be completed.')];
    }
    return [ShipRepaired(repairedHp: quote.restoredHp, goldCost: quote.goldCost,
      newHp: ship!.currentHp, normalWorkUsed: quote.normalWork)];
  }

  List<GameEvent> _handleUpgradeShip() {
    if (ship == null) throw StateError('No ship available');
    if (phase != SessionPhase.respiteIsland && phase != SessionPhase.stronghold) {
      throw StateError('Ship refits are only available at a voyage Haven or stronghold');
    }
    if (phase == SessionPhase.respiteIsland && !canUseVoyageShipwright) {
      return const <GameEvent>[
        NarrationEvent('No traveling shipwright dwells on this secluded atoll to refit your vessel.'),
      ];
    }
    final currentLevel = ship!.level;
    if (currentLevel >= 4) {
      return <GameEvent>[
        NarrationEvent('${ship!.name} has reached maximum naval refit tier (Level 4)!'),
      ];
    }
    final cost = calculateShipUpgradeCost(currentLevel);
    if (ship!.gold < cost) {
      return <GameEvent>[
        NarrationEvent('Insufficient gold to refit ${ship!.name} (Requires ${cost}g, have ${ship!.gold}g).'),
      ];
    }

    ship!.gold -= cost;
    upgradeShipState(ship!);

    return <GameEvent>[
      ShipUpgraded(
        ship: ship!,
        newLevel: ship!.level,
        goldCost: cost,
      ),
    ];
  }

  List<GameEvent> _handleTemperHardpoint(HardpointType slot) {
    if (ship == null) throw StateError('No ship available');
    if (phase != SessionPhase.respiteIsland && phase != SessionPhase.stronghold) {
      throw StateError('Fitting tempering is only available at a voyage Haven or stronghold');
    }
    if (phase == SessionPhase.respiteIsland && !canUseVoyageShipwright) {
      return const <GameEvent>[
        NarrationEvent('No master armourer dwells on this secluded atoll to temper your fittings.'),
      ];
    }
    final canonical = slot.canonical;
    final currentMark = ship!.markForHardpoint(canonical);
    if (currentMark >= 3) {
      return <GameEvent>[
        NarrationEvent('${canonical.displayName} fitting has already reached maximum temper (Mk III)!'),
      ];
    }
    final cost = calculateHardpointTemperCost(currentMark);
    if (ship!.gold < cost) {
      return <GameEvent>[
        NarrationEvent(
          'Insufficient gold to temper ${canonical.displayName} fitting (Requires ${cost}g, have ${ship!.gold}g).',
        ),
      ];
    }

    ship!.gold -= cost;
    temperShipHardpoint(ship!, canonical);
    final newMark = ship!.markForHardpoint(canonical);

    return <GameEvent>[
      HardpointTempered(
        slot: canonical,
        newMark: newMark,
        goldCost: cost,
      ),
      NarrationEvent(
        'Tempered ${canonical.displayName} mount to ${ship!.markLabelForHardpoint(canonical)} (+20% base potency)!',
      ),
    ];
  }

  List<GameEvent> _handleCareenHullAtIsland() {
    if (phase != SessionPhase.respiteIsland || ship == null || isRepairRefitStop) {
      throw StateError('Cannot careen hull outside of respite island');
    }
    if (hasChosenIslandDuty) {
      return const <GameEvent>[
        NarrationEvent("The crew's shore duty is already spent on this island haven; tides compel the ship to depart."),
      ];
    }
    final careenPct = isCurrentIslandHaven ? seaChart.tuning.services.havenCareenFraction : seaChart.tuning.services.coveCareenFraction;
    var nominal = (ship!.maxHp * careenPct);
    if (profile.isPactActive(CovenantPactId.brittleOak)) {
      nominal *= 0.75;
    }
    final healAmount = ship!.previewHealing(nominal);
    if (healAmount <= 0) {
      return const [
        NarrationEvent('Hull timbers are already in pristine condition!'),
      ];
    }
    ship!.heal(nominal);
    hasCareenedAtCurrentIsland = true;
    return <GameEvent>[
      HullCareened(repairedHp: healAmount, newHp: ship!.currentHp),
      NarrationEvent(
        isCurrentIslandHaven
            ? 'The shipwrights careened the hull in the calm shallows of the Grand Haven, caulking seams with oakum and pitch (+$healAmount HP).'
            : 'The crew careened the hull on the sands of the secluded cove, caulking the worst breaches with driftwood pitch (+$healAmount HP).',
      ),
    ];
  }

  List<GameEvent> _handleDrillGunnersAtIsland() {
    if (phase != SessionPhase.respiteIsland || ship == null || isRepairRefitStop) {
      throw StateError('Cannot drill gunners outside of respite island');
    }
    if (hasChosenIslandDuty) {
      return const <GameEvent>[
        NarrationEvent("The crew's shore duty is already spent on this island haven; tides compel the ship to depart."),
      ];
    }
    final bonus = seaChart.tuning.services.drillAccuracy;
    gunneryAccuracyBoon = gunneryAccuracyBoon - shoreDrillBoon + bonus;
    shoreDrillBoon = bonus;
    hasDrilledAtCurrentIsland = true;
    return <GameEvent>[
      GunnersDrilled(bonusHitChance: bonus),
      NarrationEvent(
        'Gunners sighted their cannons and practiced volleys (+$bonus% accuracy throughout the next battle).',
      ),
    ];
  }

  List<GameEvent> _handleForageShoalsAtIsland() {
    if (phase != SessionPhase.respiteIsland || ship == null || isRepairRefitStop) {
      throw StateError('Cannot forage shoals outside of respite island');
    }
    if (hasChosenIslandDuty) {
      return const <GameEvent>[
        NarrationEvent("The crew's shore duty is already spent on this island haven; tides compel the ship to depart."),
      ];
    }
    final bounty = isCurrentIslandHaven
        ? rng.nextIntRange(seaChart.tuning.services.havenForageMin, seaChart.tuning.services.havenForageMax)
        : rng.nextIntRange(seaChart.tuning.services.coveForageMin, seaChart.tuning.services.coveForageMax);
    ship!.gold += bounty;
    hasForagedAtCurrentIsland = true;
    return <GameEvent>[
      IslandForaged(goldFound: bounty),
      NarrationEvent(
        isCurrentIslandHaven
            ? 'The landing party foraged the haven shoals and trading drift, recovering $bounty gold doubloons.'
            : 'The landing party scavenged the cove beach and tide pools, recovering $bounty gold doubloons.',
      ),
    ];
  }

  List<GameEvent> _handleDepartIsland() {
    if (phase != SessionPhase.respiteIsland) {
      throw StateError('Cannot depart island from $phase');
    }
    return _handleTakeHelm();
  }

  List<GameEvent> _handleSalvageShipwreck(ShipwreckChoice choice) {
    throw StateError('Selectable hold/strongbox/timbers rewards are retired. Choose the current wreck recovery action.');
  }

  List<GameEvent> _startWreckBattle({required bool approach}) {
    final wreck = currentWreck!;
    wreck.approachAmbush = approach;
    wreck.cargo ??= generateWreckCargo(wreck, seaChart.tuning.wrecks, quick: false);
    wreck.threat ??= generateWreckThreat(wreck, seaChart.currentRegionIndex,
        seaChart.currentDifficulty, approach: approach,
        apexEmergence: profile.isPactActive(CovenantPactId.apexEmergence), tuning: seaChart.tuning.wrecks);
    wreck.stage = WreckStage.fighting;
    return [NarrationEvent(approach
        ? 'A lurking creature bursts from the wreck before the crew can assess the holds!'
        : 'A creature closes on the crew during the committed recovery!'),
      ..._startBattle(instantiateWreckThreat(wreck.threat!))];
  }

  List<GameEvent> _handleChooseWreckRecovery(String wreckId, WreckRecoveryChoice choice) {
    final wreck = currentWreck;
    if (phase != SessionPhase.shipwreck || ship == null || !ship!.isAlive ||
        wreck == null || wreck.id != wreckId) {
      throw StateError('This wreck recovery request is no longer current.');
    }
    if (wreck.isSettled) {
      if (choice == WreckRecoveryChoice.depart) return _handleTakeHelm();
      return const [NarrationEvent('This wreck has already been resolved.')];
    }
    if (choice == WreckRecoveryChoice.depart) {
      throw StateError('Resolve the current wreck before departing.');
    }
    if (choice == WreckRecoveryChoice.recoverClearedCargo) {
      if (wreck.stage != WreckStage.recovery || !wreck.threatCleared) {
        throw StateError('No cleared wreck cargo awaits recovery.');
      }
      return _claimWreckCargo();
    }
    if (wreck.stage != WreckStage.assessment) {
      throw StateError('The wreck threat must be resolved before recovering cargo.');
    }
    if (choice == WreckRecoveryChoice.passBy) {
      wreck.stage = WreckStage.passed;
      seaChart.recordCurrentOutcome(wreckPassed: true);
      hasSalvagedCurrentWreck = true;
      wreckSalvageReceipt = ['Sailed past the wreck empty.'];
      return [const NarrationEvent('The crew leaves the wreck and its cargo behind.'), ..._handleTakeHelm()];
    }
    if (choice == WreckRecoveryChoice.quickSalvage) {
      if (wreck.condition == WreckCondition.fresh) {
        throw StateError('Fresh wrecks require committed recovery or empty departure.');
      }
      wreck.cargo = generateWreckCargo(wreck, seaChart.tuning.wrecks, quick: true);
      wreck.stage = WreckStage.recovery;
      return _claimWreckCargo();
    }
    if (wreck.condition == WreckCondition.pickedClean) {
      throw StateError('Only small quick salvage remains at this picked-clean wreck.');
    }
    wreck.committed = true;
    wreck.cargo = generateWreckCargo(wreck, seaChart.tuning.wrecks, quick: false);
    if (wreckCommittedFight(wreck, seaChart.tuning.wrecks)) {
      return _startWreckBattle(approach: false);
    }
    wreck.stage = WreckStage.recovery;
    return _claimWreckCargo();
  }

  List<GameEvent> _claimWreckCargo() {
    final wreck = currentWreck!;
    if (wreck.stage != WreckStage.recovery || wreck.cargo == null) {
      throw StateError('No cargo is available to claim.');
    }
    final cargo = wreck.cargo!;
    wreck.stage = WreckStage.receipt; // Spend ownership before applying rewards.
    seaChart.recordCurrentOutcome(wreckRecovered: true);
    hasSalvagedCurrentWreck = true;
    profile.metaInventory.add(seaGlass: cargo.seaGlass, depthWroughtIron: cargo.iron);
    ship!.gold += cargo.gold;
    pendingLoot.addAll(cargo.supplies);
    wreckSalvageReceipt = [
      '${cargo.seaGlass} Sea Glass',
      if (cargo.iron > 0) '${cargo.iron} Depth-Wrought Iron',
      if (cargo.gold > 0) '${cargo.gold} gold doubloons',
      for (final item in cargo.supplies) 'Recovered ${item.name}.',
      if (cargo.supplies.isEmpty) 'No usable consumable found.',
    ];
    return [MetaCurrenciesAwarded(seaGlass: cargo.seaGlass, depthWroughtIron: cargo.iron,
        reason: 'Recovered mixed wreck cargo'),
      NarrationEvent('Wreck cargo recovered: ${wreckSalvageReceipt.join(' • ')}')];
  }

  List<GameEvent> _handleClaimExpeditionVictory() {
    return _handleResolveCalderaClimax(CalderaClimaxChoice.shatterCore);
  }

  List<GameEvent> _handleResolveCalderaClimax(CalderaClimaxChoice choice) {
    if (phase != SessionPhase.expeditionVictory) {
      throw StateError('Cannot resolve caldera climax from $phase');
    }

    final narrative = EldritchLore.calderaClimax[choice]!.narrativeOutcome;
    calderaOutcome = choice;
    hasReadCalderaOutcome = false;
    switch (choice) {
      case CalderaClimaxChoice.shatterCore:
        // Consume the Leviathan Core to detonate and collapse the Abyssal Font
        if (profile.metaInventory.leviathanCore > 0) {
          profile.metaInventory.spend(leviathanCore: 1);
        }
        profile.hasShatteredFont = true;
        final prevPhase = phase.displayName;
        phase = SessionPhase.ended;
        return <GameEvent>[
          PhaseChanged(previousPhase: prevPhase, newPhase: phase.displayName),
          CalderaClimaxResolved(
            choice: choice,
            captainName: captainName,
            narrative: narrative,
          ),
          NarrationEvent(
            narrative,
          ),
        ];

      case CalderaClimaxChoice.claimCore:
        // Retain the Core, unlock the Covenant of the Deep, and loop to the next heir
        profile.hasUnlockedCovenant = true;
        profile.ascensionLoopCount++;
        lineage.recordDeath(CaptainRecord(
          captainName: captainName,
          shipName: ship?.name ?? 'Flagship',
          shipClass: ship?.shipClass ?? ShipClass.standard,
          monstersDefeated: monstersDefeatedThisLife,
          highestDifficultyReached: highestDifficultyThisLife,
          causeOfDeath: EldritchLore.claimLedgerCause,
        ));
        pendingHeirCandidates = generateHeirCandidates(
          rng: rng,
          previousCaptainName: captainName,
          nemesisSpecies: profile.activeNemesis?.species,
          count: 3,
        );
        final prevPhase = phase.displayName;
        phase = SessionPhase.death;
        return <GameEvent>[
          PhaseChanged(previousPhase: prevPhase, newPhase: phase.displayName),
          CalderaClimaxResolved(
            choice: choice,
            captainName: captainName,
            narrative: narrative,
          ),
          NarrationEvent(narrative),
        ];
    }
  }

  List<GameEvent> _handleAcknowledgeCalderaOutcome() {
    if (calderaOutcome == null ||
        (phase != SessionPhase.death && phase != SessionPhase.ended)) {
      throw StateError('No Caldera outcome is awaiting acknowledgement');
    }
    hasReadCalderaOutcome = true;
    return <GameEvent>[];
  }

  static const List<String> _islandAdjectives = [
    'Sheltered',
    'Whispering',
    'Cormorant',
    'Barnacle',
    "Smuggler's",
    'Seagull',
    'Fogbound',
    'Sunken',
    'Coral',
    'Osprey',
  ];

  static const List<String> _islandNouns = [
    'Shoal',
    'Key',
    'Spit',
    'Atoll',
    'Haven',
    'Cove',
    'Reach',
    'Reef',
  ];

  String _generateIslandName() {
    final adj = _islandAdjectives[rng.nextInt(_islandAdjectives.length)];
    final noun = _islandNouns[rng.nextInt(_islandNouns.length)];
    return '$adj $noun';
  }

  static const List<String> _shipwreckNames = [
    'The Forsaken Galleon',
    'Derelict of the Mary Celeste',
    'The Shattered Caravel',
    'The Ghost Brigantine',
    'Wreck of the Black Pearl',
    "The Sea Rover's Ruin",
    'Hulk of the Albatross',
  ];

  String _generateShipwreckName() {
    return _shipwreckNames[rng.nextInt(_shipwreckNames.length)];
  }

  List<GameEvent> _handleClaimSmugglerGift(int stockIndex) {
    if (!canClaimSmugglerGift) {
      throw StateError('No free Smuggler gift can be claimed.');
    }
    if (stockIndex < 0 || stockIndex >= smugglerStock.length) {
      throw RangeError.index(stockIndex, smugglerStock);
    }
    final gift = smugglerStock.removeAt(stockIndex);
    ship!.addCargo(gift);
    hasClaimedSmugglerGift = true;
    return [
      ItemAcquired(item: gift),
      NarrationEvent("Smuggler's Kin: the crew gifts you ${gift.name}."),
    ];
  }

  List<GameEvent> _handleDepartSmuggler() {
    if (phase != SessionPhase.smuggler) {
      throw StateError('Cannot depart smuggler from $phase');
    }
    return _handleTakeHelm();
  }

  List<GameEvent> _handleAcceptShrineBlessing(OceanPower power, HardpointType slot) {
    if (phase != SessionPhase.shrine || ship == null) {
      throw StateError('Cannot accept a blessing outside of shrine phase');
    }
    if (hasCommunedAtCurrentShrine) {
      return const [
        NarrationEvent('The altar has gone cold; its blessing is already bestowed.'),
      ];
    }
    if (!shrineManifestedPowers.contains(power)) {
      throw StateError('That Primordial has not manifested at this shrine');
    }
    final restriction = shrineBlessingRestriction(power, slot);
    if (restriction != null) throw StateError(restriction);
    final blessing = previewShrineBlessing(ship!, power, slot);
    if (blessing == null) {
      throw StateError(
          'This fitting is dedicated to another power or already sovereign');
    }
    ship!.blessings[slot] = blessing;
    hasCommunedAtCurrentShrine = true;
    return [
      NarrationEvent('${blessing.title}: ${blessing.tierLabel}. ${blessing.description}'),
    ];
  }

  List<GameEvent> _handleCommuneWithShrine(ShrineChoice choice) {
    if (phase != SessionPhase.shrine || ship == null) {
      throw StateError('Cannot commune at shrine outside of shrine phase');
    }
    if (hasCommunedAtCurrentShrine && choice != ShrineChoice.leave) {
      return const <GameEvent>[
        NarrationEvent('The altar has gone cold; the spirits accept no further offerings.'),
      ];
    }
    final events = <GameEvent>[];
    switch (choice) {
      case ShrineChoice.tribute:
        if (ship!.gold < 30) {
          return const <GameEvent>[
            NarrationEvent('The shrine demands an offering of 30 gold doubloons to grant the sea\'s favor.'),
          ];
        }
        ship!.gold -= 30;
        hasCommunedAtCurrentShrine = true;
        gunneryAccuracyBoon += 15;
        events.add(ShrineCommuned(
          shrineName: currentShrineName,
          choice: choice,
          outcomeNarrative: 'Golden coins sink into the deep. A gentle following wind guides your guns (+15% accuracy boon).',
        ));
      case ShrineChoice.abyssalPact:
        final damage = (ship!.maxHp * 0.20).round();
        if (ship!.currentHp <= damage) {
          return const <GameEvent>[
            NarrationEvent('Your hull is too fractured to endure the abyssal pact without foundering!'),
          ];
        }
        ship!.applyDamage(damage);
        hasCommunedAtCurrentShrine = true;
        final relic = randomConsumable(seaChart.currentDifficulty + 1, rng);
        if (ship!.cargo.length < ship!.maxCargo) {
          ship!.addCargo(relic);
          events.add(ItemAcquired(item: relic));
        } else {
          pendingLoot.add(relic);
        }
        events.add(ShrineCommuned(
          shrineName: currentShrineName,
          choice: choice,
          outcomeNarrative: 'Timbers groan and splinter (-$damage HP)! From the foaming brine, the deep bestows ${relic.name}.',
        ));
      case ShrineChoice.ancientRunes:
        hasCommunedAtCurrentShrine = true;
        final nextRow = seaChart.currentLeg + 1;
        seaChart.revealRow(nextRow);
        gunneryAccuracyBoon = gunneryAccuracyBoon - runicGuidanceBoon + 10;
        runicGuidanceBoon = 10;
        events.add(ShrineCommuned(
          shrineName: currentShrineName,
          choice: choice,
          outcomeNarrative: 'The runes glow with phosphorescence! The fog lifts across the soundings ahead, and the crew charts safe passage (+10% accuracy boon).',
        ));
      case ShrineChoice.leave:
        return _handleDepartShrine();
    }
    return events;
  }

  List<GameEvent> _handleDepartShrine() {
    if (phase != SessionPhase.shrine) {
      throw StateError('Cannot depart shrine from $phase');
    }
    return _handleTakeHelm();
  }

  static const List<String> _smugglerAdjectives = [
    'The Shadowed',
    "Cutthroat's",
    'The Midnight',
    'The Salt-Stained',
    'Corsair\'s',
    'The Gilded',
    'The Phantom',
    'The Smuggler\'s',
  ];

  static const List<String> _smugglerTypes = [
    'Ketch',
    'Brigantine',
    'Barque',
    'Skiff',
    'Sloop',
    'Pinnace',
  ];

  String _generateSmugglerName() {
    final adj = _smugglerAdjectives[rng.nextInt(_smugglerAdjectives.length)];
    final type = _smugglerTypes[rng.nextInt(_smugglerTypes.length)];
    return '$adj $type';
  }

  static const List<String> _shrineTitles = [
    'Shrine of the Abyssal Siren',
    'Monolith of the North Star',
    'Altar of the Ancient Tides',
    'The Phosphor Spire',
    'The Drowned Mariner\'s Obelisk',
    'Pillar of the Leviathan',
    'Sanctum of the Weeping Coral',
  ];

  String _generateShrineName() {
    return _shrineTitles[rng.nextInt(_shrineTitles.length)];
  }

  String _generateShrineLore() {
    final region = seaChart.currentRegionIndex;
    if (region == 0) {
      const lore = [
        'Runes carved into barnacled basalt: "Beware the Siren Shoals, where sweet voices mask the crushing embrace of the multi-tentacled Kraken."',
        'Ancient logbook scrap embedded in coral: "We charted seven reefs before the beast struck. The cannons shattered its tentacles, yet deeper perils lie beyond."',
        'Petrified ship wheel inscribed with gold leaf: "Hunter\'s Respite was once a fortress of twelve ships. Only one returned from the Leviathan Trench."',
      ];
      return lore[rng.nextInt(lore.length)];
    } else if (region == 1) {
      const lore = [
        'Etched into petrified drift-kelp: "The Sargasso Drift has swallowed an armada of ghost galleons. The World Serpent encircles their bones in phosphorescent coils."',
        'Runic brass compass pointing into the fog: "He who strikes the serpent\'s flank with piercing ordnance shall pierce its coiling evasion."',
        'Inscribed upon a shattered figurehead: "We were stalled three weeks in the doldrums before the sea began to churn with venom."',
      ];
      return lore[rng.nextInt(lore.length)];
    } else {
      const lore = [
        'Carved into smoking obsidian: "The Boiling Reach is the crucible of the deep. Steam vents hide the Ancient Leviathan whose scales withstand any normal blast."',
        'Iron plaque scorched by sulfurous fire: "Only heavy broadsides and tempered hulls will endure the thermal calderas of the final domain."',
        'Ancient mariner proverb carved in stone: "The monster shall perish, and the captain\'s glory shall endure across the age of sail."',
      ];
      return lore[rng.nextInt(lore.length)];
    }
  }

  List<GameEvent> _handleContinueLineage(
    String heirName,
    ShipClass chosenClass, {
    BloodlineTrait? boon,
    BloodlineTrait? quirk,
  }) {
    if (phase != SessionPhase.death || ship == null) {
      throw StateError('Cannot continue lineage outside of death phase');
    }
    if (quirk?.id == BloodlineTraitId.bloodOath && profile.activeNemesis == null) {
      throw StateError('Blood Oath requires an eligible Nemesis');
    }
    final blueprintId = BlueprintId.fromShipClass(chosenClass);
    if (!profile.isBlueprintUnlocked(blueprintId)) {
      throw StateError('Blueprint $blueprintId is not unlocked');
    }
    captainName = heirName;
    calderaOutcome = null;
    hasReadCalderaOutcome = false;
    activeBoon = boon;
    activeQuirk = quirk;
    stormSeerRedrawRegion = null;
    gunneryAccuracyBoon = 0;
    runicGuidanceBoon = 0;
    shoreDrillBoon = 0;
    paidRepairWork = PaidRepairWork();
    currentWreck = null;
    shrineOmenSeed = rng.nextInt(1 << 30);
    _resetCombatActionStages();
    pendingHeirCandidates = <HeirCandidate>[];

    final previousShip = ship!;
    final armamentTier = profile.armamentTierFor(blueprintId);
    final heirShip = createFlagshipFromBlueprint(
      blueprintId,
      level: 1,
      rng: rng,
      armamentTier: armamentTier,
      hasExpandedAuxiliarySlot: profile.hasExpandedAuxiliarySlot,
      bonusMaxHp: profile.monumentBonusMaxHp,
    )..shipClass = chosenClass;
    _syncVesselCaptainTraits(heirShip);

    if (previousShip.shipClass == ShipClass.freighter ||
        previousShip.shipClass == ShipClass.corsair) {
      heirShip.gold = (previousShip.gold * 0.05).toInt();
      for (final item in previousShip.cargo) {
        if (heirShip.cargo.length < heirShip.maxCargo) {
          heirShip.cargo.add(item);
        } else {
          break;
        }
      }
    } else {
      heirShip.gold = 25;
      heirShip.cargo.clear();
    }
    ship = heirShip;
    monstersDefeatedThisLife = 0;
    highestDifficultyThisLife = 0;
    seaChart.reset(resetMaxRow: true);
    refreshMerchantStock(1);

    final prevPhase = phase.displayName;
    phase = SessionPhase.port;
    return <GameEvent>[
      PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ),
      HeirSelected(
        heirName: heirName,
        chosenClass: chosenClass,
        boon: boon,
        quirk: quirk,
      ),
    ];
  }

  List<GameEvent> _handleAbandonHunt() {
    if (phase != SessionPhase.death) {
      throw StateError('Cannot abandon hunt outside of death phase');
    }
    final prevPhase = phase.displayName;
    phase = SessionPhase.ended;
    return <GameEvent>[
      PhaseChanged(
        previousPhase: prevPhase,
        newPhase: phase.displayName,
      ),
      NarrationEvent(
        'The Undying Sea has prevailed, but no longer shall the Hunt consume your lineage...',
      ),
    ];
  }
}

extension _StringCaseExtension on String {
  bool equalsIgnoreCase(String other) => toLowerCase() == other.toLowerCase();
}
