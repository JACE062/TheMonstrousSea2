import 'package:flutter/material.dart';

import '../game_controller.dart';
import '../theme/ink_theme.dart';
import 'ink_button.dart';

/// Transient reading position retained by a Chronicle host between openings.
class CombatLogScrollState {
  double offset = 0;
  bool followingLatest = true;
}

/// Scrollable maritime combat log drawer displaying the chronicle of battle
/// with clear visual separation: ship actions on the left, beast actions on the right,
/// and ambient events centered.
class CombatLogView extends StatefulWidget {
  const CombatLogView({
    super.key,
    required this.entries,
    this.scrollState,
    this.showHeader = true,
  });

  /// Accepts either [List<CombatLogEntry>] or [List<String>] for maximum versatility.
  final List<dynamic> entries;
  final CombatLogScrollState? scrollState;
  final bool showHeader;

  @override
  State<CombatLogView> createState() => _CombatLogViewState();
}

class _CombatLogViewState extends State<CombatLogView> {
  late final ScrollController _scrollController;
  bool _followingLatest = true;
  bool _userScrolling = false;
  bool _scrollScheduled = false;
  bool _jumpingToLatest = false;
  late int _entryCount;

  @override
  void initState() {
    super.initState();
    _followingLatest = widget.scrollState?.followingLatest ?? true;
    _scrollController = ScrollController(
      initialScrollOffset: widget.scrollState?.offset ?? 0,
      keepScrollOffset: widget.scrollState == null,
    )..addListener(_rememberPosition);
    _entryCount = widget.entries.length;
    _scheduleLatest();
  }

  @override
  void didUpdateWidget(covariant CombatLogView oldWidget) {
    super.didUpdateWidget(oldWidget);
    // The controller appends to the same list; oldWidget.entries is not a
    // snapshot. Keep a separate count rather than comparing list identities.
    if (_entryCount != widget.entries.length) {
      _entryCount = widget.entries.length;
      if (_followingLatest) _scheduleLatest();
    }
  }

  @override
  void dispose() {
    _rememberPosition();
    _scrollController.dispose();
    super.dispose();
  }

  void _rememberPosition() {
    final state = widget.scrollState;
    if (state == null) return;
    state.followingLatest = _followingLatest;
    if (_scrollController.hasClients) {
      state.offset = _scrollController.offset;
    }
  }

  void _scheduleLatest() {
    if (_scrollScheduled) return;
    _scrollScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollScheduled = false;
      if (!mounted ||
          !_followingLatest ||
          _userScrolling ||
          !_scrollController.hasClients) {
        return;
      }
      final position = _scrollController.position;
      if (position.extentAfter > 0) {
        _jumpingToLatest = true;
        try {
          _scrollController.jumpTo(position.maxScrollExtent);
        } finally {
          _jumpingToLatest = false;
        }
        // Lazy, variable-height rows can revise the extent after this jump.
        // Continue after layout until the real end is reached.
        _scheduleLatest();
      }
    });
    WidgetsBinding.instance.scheduleFrame();
  }

  bool _onScroll(ScrollNotification notification) {
    if (notification.depth != 0 || _jumpingToLatest) return false;
    // Includes drag, wheel, scrollbar and keyboard scrolling, while ignoring
    // the synchronous notifications from our own live-end jumps.
    if (notification is ScrollStartNotification) {
      _userScrolling = true;
    }
    if (_userScrolling) {
      final atLatest = notification.metrics.extentAfter <= 24;
      if (_followingLatest != atLatest) {
        setState(() => _followingLatest = atLatest);
      }
      if (notification is ScrollEndNotification) {
        _userScrolling = false;
        if (_followingLatest) _scheduleLatest();
      }
      _rememberPosition();
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final entries = widget.entries;
    return Container(
      decoration: BoxDecoration(
        color: InkTheme.parchmentSurface,
        border: Border.all(color: InkTheme.inkMuted, width: 1.2),
        borderRadius: BorderRadius.circular(4),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: LayoutBuilder(
        builder: (context, bounds) => Column(
          children: [
            // Header legend differentiating the sides
            // On short windows the latest entry needs the available reading room.
            if (widget.showHeader && bounds.maxHeight >= 60) ...[
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    if (constraints.maxWidth < 640) {
                      return Text(
                        'CHRONICLE OF BATTLE',
                        style: InkTheme.caption.copyWith(
                          fontSize: 11.5,
                          color: InkTheme.inkMuted,
                        ),
                      );
                    }
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: InkTheme.verdigrisGreen,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'VESSEL VOLLEYS',
                              style: InkTheme.statLabel.copyWith(
                                fontSize: 11.5,
                                color: InkTheme.verdigrisGreen,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ],
                        ),
                        Text(
                          'CHRONICLE OF BATTLE',
                          style: InkTheme.caption.copyWith(
                            fontSize: 11.5,
                            letterSpacing: 1.2,
                            color: InkTheme.inkMuted,
                          ),
                        ),
                        Row(
                          children: [
                            Text(
                              'BEAST STRIKES',
                              style: InkTheme.statLabel.copyWith(
                                fontSize: 11.5,
                                color: InkTheme.crimsonAccent,
                                letterSpacing: 0.8,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: InkTheme.crimsonAccent,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                ),
              ),
              const Divider(height: 1, thickness: 0.8),
              const SizedBox(height: 4),
            ],
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(
                    child: NotificationListener<ScrollMetricsNotification>(
                      onNotification: (_) {
                        if (_followingLatest) _scheduleLatest();
                        return false;
                      },
                      child: NotificationListener<ScrollNotification>(
                        onNotification: _onScroll,
                        child: entries.isEmpty
                            ? Center(
                                child: Text(
                                  'The open swell is calm... for now.',
                                  style: InkTheme.caption,
                                ),
                              )
                            : ListView.builder(
                                controller: _scrollController,
                                itemCount: entries.length,
                                itemBuilder: (context, index) {
                                  final item = entries[index];
                                  final CombatLogEntry entry =
                                      item is CombatLogEntry
                                      ? item
                                      : CombatLogEntry(
                                          message: item.toString(),
                                          actor:
                                              item.toString().contains(
                                                    'beast',
                                                  ) ||
                                                  item.toString().contains(
                                                    'Kraken',
                                                  ) ||
                                                  item.toString().contains(
                                                    'spewed',
                                                  )
                                              ? CombatLogActor.monster
                                              : CombatLogActor.ship,
                                        );

                                  return _buildEntryRow(entry);
                                },
                              ),
                      ),
                    ),
                  ),
                  if (!_followingLatest)
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: InkButton(
                        label: 'LATEST MESSAGES',
                        compact: true,
                        onPressed: () {
                          setState(() => _followingLatest = true);
                          _rememberPosition();
                          _scheduleLatest();
                        },
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEntryRow(CombatLogEntry entry) {
    final isShip = entry.actor == CombatLogActor.ship;
    final isMonster = entry.actor == CombatLogActor.monster;
    final isAmbient = entry.actor == CombatLogActor.ambient;

    if (isAmbient) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2.5),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
            decoration: BoxDecoration(
              color: InkTheme.parchmentDark.withValues(alpha: 0.25),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              '~ ${entry.message} ~',
              style: InkTheme.caption.copyWith(
                fontSize: 12,
                fontStyle: FontStyle.italic,
                color: entry.isCritical
                    ? InkTheme.crimsonAccent
                    : InkTheme.inkMuted,
                fontWeight: entry.isCritical
                    ? FontWeight.bold
                    : FontWeight.normal,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    final alignment = isShip ? Alignment.centerLeft : Alignment.centerRight;
    final borderColor = isShip
        ? InkTheme.verdigrisGreen
        : InkTheme.crimsonAccent;
    final badgeColor = isShip
        ? InkTheme.verdigrisGreen
        : InkTheme.crimsonAccent;
    final badgeLabel = isShip ? 'VESSEL' : 'BEAST';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.5),
      child: Align(
        alignment: alignment,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 580),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isShip
                  ? InkTheme.parchmentHighlight.withValues(alpha: 0.7)
                  : InkTheme.crimsonAccent.withValues(alpha: 0.08),
              border: Border(
                left: isShip
                    ? BorderSide(color: borderColor, width: 3)
                    : BorderSide.none,
                right: isMonster
                    ? BorderSide(color: borderColor, width: 3)
                    : BorderSide.none,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(isShip ? 0 : 4),
                bottomLeft: Radius.circular(isShip ? 0 : 4),
                topRight: Radius.circular(isMonster ? 0 : 4),
                bottomRight: Radius.circular(isMonster ? 0 : 4),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (isShip) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 1,
                    ),
                    margin: const EdgeInsets.only(right: 6, top: 1),
                    decoration: BoxDecoration(
                      color: badgeColor.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(2),
                    ),
                    child: Text(
                      badgeLabel,
                      style: InkTheme.statLabel.copyWith(
                        fontSize: 11,
                        color: badgeColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
                Flexible(
                  child: Text(
                    entry.message,
                    style: InkTheme.caption.copyWith(
                      color: entry.isCritical
                          ? InkTheme.crimsonAccent
                          : InkTheme.inkPrimary,
                      fontSize: 14.5,
                      fontWeight: entry.isCritical
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                ),
                if (isMonster) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 1,
                    ),
                    margin: const EdgeInsets.only(left: 6, top: 1),
                    decoration: BoxDecoration(
                      color: badgeColor.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(2),
                    ),
                    child: Text(
                      badgeLabel,
                      style: InkTheme.statLabel.copyWith(
                        fontSize: 11,
                        color: badgeColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
